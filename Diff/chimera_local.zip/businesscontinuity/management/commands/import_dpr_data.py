from django.core.management.base import BaseCommand
from businesscontinuity.management.commands.import_from_json import import_from_json_file

class Command(BaseCommand):
    help = "Import the data from a local JSON file via utils.py"

    def add_arguments(self, parser):
        parser.add_argument('--verbose', action='store_true', help='Print progress to the console every 1000 servers')

    def handle(self, *args, **options):
        verbose = options.get('verbose', False)
        success, message = import_from_json_file(verbose)
        # Disabled if redirected to a log file
        #if success:
        #    self.stdout.write(self.style.SUCCESS(message))
        #else:
        #    self.stderr.write(self.style.ERROR(message))

