import json
import datetime
import math
import os
import requests

from django.conf import settings
from django.db import connection as django_connection, transaction
from businesscontinuity.models import ServerUnique, Server, ServerStaging, ImportStatus

VARIATION_ALLOWED = 0.1  # 10%
DPR_API_URL="http://localhost:8000/api/get-json/"
DPR_FILE_PATH="/home/PREVOSTJ/data/dpr_saphir.json"
API_TOKEN = "ded9a0a452b85bffab6dbe1f7e9cacbef34870cb"  #"9d35652a42e1713cbff77d6a1cc0c5ede3168051"
LOG_PATH="/home/PREVOSTJ/data/dpr_import.log"

field_mapping = {
    "SERVER_ID": "SERVER_ID",
    "ITCONTINUITY_LEVEL": "SERVER_APM-DETAILS__ITCONTINUITYCRITICALITY",
    "DAP_NAME": "SNOW_SERVICE__U_LABEL",
    "DAP_AUID": "SNOW_AUID_VALUE",
    "DATACENTER": "PAMELA__DATACENTER",
    "TECH_FAMILY": "PAMELA__TECHFAMILY",
    "MACHINE_TYPE": "SERVER_MACHINE_TYPE_VALUE",
    "VM_TYPE": "PAMELA__VMTYPE",
    "AFFINITY": "PAMELA__AFFINITY",
    "VITAL_LEVEL": "SERVER_APM-SERVICES__VITALAPPLICATION",
    "DATABASE_TECHNO": "PAMELA_DATABASE_TECH",
    "DATABASE_DB_CI": "DATABASE_DB_CI_VALUE",
    "SUPPORT_GROUP": "SNOW_SERVER__SUPPORT_GROUP",
    "IT_CLUSTER": "SERVER_APM-DETAILS__ITCLUSTER"
}


def write_log(message):
    print(message)
    with open(LOG_PATH, 'a') as log_file:
        log_file.write(message + '\n')
        

# Cache field lengths
field_lengths = {
    field: (
        ServerStaging._meta.get_field(field).max_length
        if hasattr(ServerStaging._meta.get_field(field), 'max_length')
        else None
    )
    for field in field_mapping.keys()
}

def clean_value(value, field_name):
    """ Clean and truncate string values based on the field length from the model. """
    if value is None or (isinstance(value, float) and math.isnan(value)) or value == "none":
        return "EMPTY"

    if not isinstance(value, str):
        value = str(value)

    value = value.replace("\r\n", "")

    max_length = field_lengths.get(field_name)
    if max_length and len(value) > max_length:
        return value[:max_length]

    return value
    

def recreate_staging_table_sqlite(db_path):
    import sqlite3
    conn = sqlite3.connect(db_path)
    try:
        cursor = conn.cursor()
        cursor.execute("DROP TABLE IF EXISTS businesscontinuity_serverstaging;")
        cursor.execute("PRAGMA table_info(businesscontinuity_server);")
        columns = cursor.fetchall()
        column_definitions = ", ".join([f"{col[1]} {col[2]}" for col in columns])
        create_table_sql = f"CREATE TABLE businesscontinuity_serverstaging ({column_definitions});"
        cursor.execute(create_table_sql)
        conn.commit()
    except sqlite3.Error as e:
        write_log(f"[{datetime.datetime.now()}] SQLite error: {e}")

    finally:
        cursor.close()
        conn.close()


def recreate_staging_table():
    with django_connection.cursor() as cursor:
        cursor.execute("DROP TABLE IF EXISTS businesscontinuity_serverstaging;")
        cursor.execute("CREATE TABLE businesscontinuity_serverstaging (LIKE businesscontinuity_server INCLUDING ALL);")


def import_from_json_file(verbose=False):
    start_time = datetime.datetime.now()
    write_log(f"[{start_time}] Start import of the servers...")
    
    """
    try:
        if os.path.exists(DPR_FILE_PATH):
            write_log(f"[{start_time}] Backing up the existing JSON file...")
            backup_path = f"{DPR_FILE_PATH}.bak"
            if os.path.exists(backup_path):
                os.remove(backup_path)
            os.rename(DPR_FILE_PATH, backup_path)
            write_log(f"[{datetime.datetime.now()}] Backup created: {backup_path}")
        else:
            write_log(f"[{datetime.datetime.now()}] No existing file to back up.")
    except Exception as e:
        msg = f"Error during the file backup: {e}"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        return False, msg    
    
    write_log(f"[{start_time}] Getting the json form DPR...")
    try:
        headers = {
            "Authorization": f"Token {API_TOKEN}"
        }
        response = requests.get(DPR_API_URL, headers=headers)
        response.raise_for_status()
        with open(DPR_FILE_PATH, 'wb') as f:
            f.write(response.content)
        write_log(f"[{datetime.datetime.now()}] JSON file successfully retrieved")
    except Exception as e:
        msg = f"Error during the API import: {e}"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        return False, msg
    """
    try:
        write_log(f"[{datetime.datetime.now()}] Reading the json...")
        with open(DPR_FILE_PATH, 'r') as f:
            data = json.load(f)
    except Exception as e:
        msg = f"Error reading the JSON: {e}"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        return False, msg

    if not isinstance(data, list):
        msg = "Invalid JSON format: list expected"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        return False, msg
        
    old_count = Server.objects.count()
    new_count = len(data)

    if old_count > 0:
        variation = abs(new_count - old_count) / old_count
        if variation > VARIATION_ALLOWED:
            msg = f"Variation too big ({variation:.2%}), import cancelled"
            ImportStatus.objects.create(success=False, message=msg, nb_entries_created=0)
            write_log(f"[{datetime.datetime.now()}] {msg}")
            return False, msg

    write_log(f"[{datetime.datetime.now()}] Recreate the ServerStaging table...")

    db_default = settings.DATABASES['default']
    if db_default['ENGINE'] == 'django.db.backends.sqlite3':
        recreate_staging_table_sqlite(db_default['NAME'])
    else:  # PostgreSQL
        recreate_staging_table()

    staging_objs = []
    created_uniques = 0
    index = 0
    progress_interval=1000

    try:
        write_log(f"[{datetime.datetime.now()}] Enumerating and preparing the ServerStaging and ServerUnique entries to create...")
        with transaction.atomic():
            existing_servers_uniques = {su.hostname: su for su in ServerUnique.objects.all()}

            for entry in data:
                index = index+1
                hostname = entry.get("SERVER_ID")
                if not hostname:
                    continue

                unique, created = ServerUnique.objects.get_or_create(
                    hostname=hostname,
                    defaults={ 'priority_asset': 'EMPTY', 'in_live_play': 'EMPTY', 'action_during_lp': 'EMPTY', 'action_during_lp_history': None,
                        'original_action_during_lp': 'EMPTY', 'original_action_during_lp_history': None, 'cluster': 'EMPTY', 'cluster_type': 'EMPTY' }
                )
                if created:
                    created_uniques += 1

                model_fields = {
                    ServerStaging._meta.get_field(m).name: clean_value(entry.get(v), m)
                    for m, v in field_mapping.items()
                }
                staging_objs.append(ServerStaging(
                    server_unique=unique,
                    **model_fields
                ))
                
                if verbose and (index % progress_interval == 0):
                    print(f"\r[{datetime.datetime.now()}] Processed {index} servers", end='', flush=True)

            if verbose:
                print("\r" + " " * 80, end='\r', flush=True)  # Clear the progress line
                
            write_log(f"[{datetime.datetime.now()}] Creating the ServerStaging and ServerUnique entries...")    
            ServerStaging.objects.bulk_create(staging_objs, batch_size=1000)
            write_log(f"[{datetime.datetime.now()}] Created {len(staging_objs)} staging entries")
            
    except Exception as e:
        msg = f"Error during the creation of ServerStaging and ServerUnique entries: {e}"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        write_log("----------------------------------------------------------------------------")
        return False, msg
        
    try:
        write_log(f"[{datetime.datetime.now()}] Swapping ServerStaging -> Server")
        with django_connection.cursor() as cursor:
            cursor.execute("BEGIN;")
            cursor.execute("DROP TABLE IF EXISTS businesscontinuity_serverbackup;")
            cursor.execute("ALTER TABLE businesscontinuity_server RENAME TO businesscontinuity_serverbackup;")
            cursor.execute("ALTER TABLE businesscontinuity_serverstaging RENAME TO businesscontinuity_server;")
            cursor.execute("COMMIT;")

        end_time = datetime.datetime.now()
        total_duration = end_time - start_time
        msg = f"Import successful: {new_count} entries imported, {created_uniques} unique servers created"
        ImportStatus.objects.create(success=True, message=msg, nb_entries_created=new_count)
        write_log(f"[{end_time}] {msg}")
        write_log(f"[{end_time}] Total duration for import: {total_duration}")
        write_log("----------------------------------------------------------------------------")

        return True, msg

    except Exception as e:
        msg = f"Error during the swap staging -> prod: {e}"
        ImportStatus.objects.create(success=False, message=msg)
        write_log(f"[{datetime.datetime.now()}] {msg}")
        write_log("----------------------------------------------------------------------------")
        return False, msg



