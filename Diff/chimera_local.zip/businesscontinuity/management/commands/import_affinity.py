import csv
from django.core.management.base import BaseCommand
from businesscontinuity.models import ServerUnique, Server, ServerStaging, ImportStatus


class Command(BaseCommand):
    help = 'Update the affinity values of the servers using a csv file'

    def add_arguments(self, parser):
        parser.add_argument(
            'csv_file',
            type=str,
            help='Path to the CSV contening server_id and affinity'
        )

    def handle(self, *args, **options):
        csv_file_path = options['csv_file']
        
        updated_count = 0
        not_found_count = 0
        error_count = 0
        
        try:
            with open(csv_file_path, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                for row in reader:
                    server_id = row.get('server_id', '').strip()
                    affinity = row.get('affinity', '').strip()
                    
                    if not server_id:
                        self.stdout.write(
                            self.style.WARNING(f'Line ignored : server_id is missinng')
                        )
                        continue
                    
                    try:
                        servers = Server.objects.filter(SERVER_ID__iexact=server_id)
                        
                        if servers.count() > 1:
                            for server in servers:
                                server.affinity = affinity
                                server.save()
                                
                            updated_count += len(servers)
                            self.stdout.write(
                                self.style.WARNING(f'⚠️ Server {server_id}: multiple servers found, affinity updated for all')
                            )
                            
                        elif servers.count() == 1:
                            server = servers.first()
                            server.affinity = affinity
                            server.save()
                            
                            updated_count += 1
                            self.stdout.write(
                                self.style.SUCCESS(f'✓ Server {server_id}: affinity updated')
                            )
                            
                        else:
                            not_found_count += 1
                            self.stdout.write(
                                self.style.WARNING(f'✗ Server {server_id}: not found in the database')
                            )
                        
                    except Server.DoesNotExist:
                        not_found_count += 1
                        self.stdout.write(
                            self.style.WARNING(f'✗ Server {server_id}: not found in the database')
                        )
                    
                    except Exception as e:
                        error_count += 1
                        self.stdout.write(
                            self.style.ERROR(f'✗ Error for the server {server_id}: {str(e)}')
                        )
            
            self.stdout.write(self.style.SUCCESS('\n=== SUMMARY ==='))
            self.stdout.write(f'Servers updated: {updated_count}')
            self.stdout.write(f'Servers not found: {not_found_count}')
            self.stdout.write(f'Errors: {error_count}')
            
        except FileNotFoundError:
            self.stdout.write(
                self.style.ERROR(f'File not found: {csv_file_path}')
            )
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Error during the reading of the file: {str(e)}')
            )
