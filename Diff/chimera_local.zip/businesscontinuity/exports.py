import csv
import os

from django.conf import settings
from openpyxl import Workbook

# Define the directory where exports will be stored
EXPORT_DIR = os.path.join(settings.MEDIA_ROOT, 'exports')


# Function to recursively get a nested attribute using a string path
def get_db_attr(obj, attr):

    parts = attr.split('.')
    for part in parts:
        if hasattr(obj, part):
            obj = getattr(obj, part)
        else:
            return None
    return obj


# Function to generate an Excel file from a list of servers
def generate_excel(filepath, servers, columns, FILTER_MAPPING):

    temp_filepath = filepath + '.tmp'
    wb = Workbook()
    ws = wb.active
    ws.title = "Servers"
    
    first_column = "SERVER_ID"  # Define SERVER_ID as first column
    columns = [col for col in columns if col != first_column]  # Avoid having SERVER_ID repeated twice
    columns = [first_column] + columns

    # Write the header row
    ws.append(columns)

    if servers.exists():
        for server in servers:
            row = []
            first_value = get_db_attr(server, FILTER_MAPPING[first_column])  # Add the value for the first column
            row.append(first_value)
            for col in columns[1:]:  # Skip the first column
                value = get_db_attr(server, FILTER_MAPPING[col])
                row.append(value)
            ws.append(row)
    else:
        print("No servers matching the applied filters were found.")

    # Save the workbook and replace the original file
    wb.save(temp_filepath)
    os.replace(temp_filepath, filepath)
        

# Function to generate a CSV file from a list of servers        
def generate_csv(filepath, servers, columns, FILTER_MAPPING):

    temp_filepath = filepath + '.tmp'
    with open(temp_filepath, 'w', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)

        first_column = "SERVER_ID"  # Define SERVER_ID as first column
        columns = [col for col in columns if col != first_column]  # Avoid having SERVER_ID repeated twice
        columns = [first_column] + columns

        # Write the header row
        writer.writerow(columns)

        # Write the data rows
        for server in servers:
            first_value = get_db_attr(server, FILTER_MAPPING[first_column])  # Add the value for the first column
            data_row = [first_value] + [get_db_attr(server, FILTER_MAPPING[col]) for col in columns[1:]]
            writer.writerow(data_row)

    # Replace the original file with the temporary file
    os.replace(temp_filepath, filepath)

