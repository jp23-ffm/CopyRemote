from django.core.management.base import BaseCommand
from inventory.management.commands.dbimport_inventory_csv import import_from_csv_file

class Command(BaseCommand):
    help = "Import the data from a local CSV file via dbimport_inventory_csv.py"

    def add_arguments(self, parser):
        parser.add_argument('--verbose', action='store_true', help='Print progress to the console every 10000/50000 servers')

    def handle(self, *args, **options):
        verbose = options.get('verbose', False)
        success, message = import_from_csv_file(verbose)
        if success:
            self.stdout.write(self.style.SUCCESS(message))
        else:
            self.stderr.write(self.style.ERROR(message))
