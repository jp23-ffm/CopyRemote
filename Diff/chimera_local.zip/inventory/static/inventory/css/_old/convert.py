import re
from collections import defaultdict

def extract_and_replace_colors(css_content):
    # Patterns pour détecter les couleurs
    hex_pattern = r'#[0-9a-fA-F]{3,8}'
    rgb_pattern = r'rgba?\([^)]+\)'
    named_colors = [
        'black', 'white', 'red', 'green', 'blue', 'yellow', 'orange', 'purple',
        'pink', 'gray', 'grey', 'brown', 'cyan', 'magenta', 'lime', 'navy',
        'teal', 'aqua', 'maroon', 'olive', 'silver', 'fuchsia', 'gold',
        'indigo', 'violet', 'tan', 'khaki', 'coral', 'salmon', 'crimson',
        'darkred', 'darkgreen', 'darkblue', 'lightgray', 'lightgrey', 'darkgray',
        'darkgrey', 'lightblue', 'lightgreen', 'lightyellow', 'whitesmoke',
        'transparent', 'inherit', 'currentColor'
    ]
    
    named_pattern = r'\b(' + '|'.join(named_colors) + r')\b'
    
    color_map = {}
    variable_counter = defaultdict(int)
    variable_categories = {}  # NOUVEAU : pour stocker la catégorie de chaque variable
    
    def get_variable_name(property_name, color_value):
        color_normalized = color_value.lower().strip()
        prop = property_name.strip().lower()
        
        # Mapper vers des catégories logiques
        if 'background' in prop or 'bg' in prop:
            category = 'bg'
        elif 'border' in prop:
            category = 'border'
        elif 'color' in prop and 'background' not in prop:
            category = 'text'
        elif 'shadow' in prop or 'box-shadow' in prop:
            category = 'shadow'
        elif 'fill' in prop or 'stroke' in prop:
            category = 'svg'
        else:
            category = 'misc'
        
        key = f"{category}-{color_normalized}"
        if key not in color_map:
            variable_counter[category] += 1
            var_name = f"--{category}-{variable_counter[category]}"
            color_map[key] = var_name
            variable_categories[var_name] = category  # NOUVEAU : stocker la catégorie
        
        return color_map[key]
    
    new_css = css_content
    colors_found = {}
    replacements = []
    
    for match in re.finditer(r'([\w-]+)\s*:\s*([^;{]+);', css_content):
        prop_name = match.group(1)
        prop_value = match.group(2).strip()
        
        if 'var(' in prop_value:
            continue
        
        color_to_replace = None
        
        hex_match = re.search(hex_pattern, prop_value)
        if hex_match:
            color_to_replace = hex_match.group(0)
        
        if not color_to_replace:
            rgb_match = re.search(rgb_pattern, prop_value)
            if rgb_match:
                color_to_replace = rgb_match.group(0)
        
        if not color_to_replace:
            named_match = re.search(named_pattern, prop_value, re.IGNORECASE)
            if named_match:
                if not any(skip in prop_value for skip in ['url(', 'calc(', 'attr(']):
                    color_to_replace = named_match.group(0)
        
        if color_to_replace:
            var_name = get_variable_name(prop_name, color_to_replace)
            colors_found[color_to_replace] = var_name
            
            old_declaration = f'{prop_name}: {prop_value};'
            new_value = prop_value.replace(color_to_replace, f'var({var_name})', 1)
            new_declaration = f'{prop_name}: {new_value};'
            
            replacements.append((old_declaration, new_declaration))
    
    for old, new in replacements:
        new_css = new_css.replace(old, new, 1)
    
    # Générer les variables CSS pour le mode clair
    variables_css = "/* MODE CLAIR (défaut) */\n:root {\n"
    
    # Grouper par catégorie CORRECTEMENT
    categories = defaultdict(list)
    for color, var_name in colors_found.items():
        category = variable_categories.get(var_name, 'misc')  # CORRIGÉ !
        categories[category].append((var_name, color))
    
    for category in ['bg', 'text', 'border', 'shadow', 'svg', 'misc']:
        if category in categories:
            variables_css += f"\n  /* {category.upper()} */\n"
            for var_name, color in sorted(categories[category]):
                variables_css += f"  {var_name}: {color};\n"
    
    variables_css += "}\n\n"
    
    # Template pour le mode sombre
    dark_mode_template = "/* MODE SOMBRE */\n:root.dark-mode {\n"
    for category in ['bg', 'text', 'border', 'shadow', 'svg', 'misc']:
        if category in categories:
            dark_mode_template += f"\n  /* {category.upper()} */\n"
            for var_name, color in sorted(categories[category]):
                dark_mode_template += f"  {var_name}: {color}; /* TODO: adapter pour le mode sombre */\n"
    dark_mode_template += "}\n\n"
    
    return variables_css, dark_mode_template, new_css, colors_found

# Usage
with open('inventory.css', 'r', encoding='utf-8') as f:
    css_content = f.read()

variables, dark_template, new_css, colors = extract_and_replace_colors(css_content)

with open('server_list_converted.css', 'w', encoding='utf-8') as f:
    f.write(variables)
    f.write(dark_template)
    f.write(new_css)

print(f"✅ {len(colors)} couleurs détectées et remplacées")
print("\nCouleurs trouvées:")
for color, var in sorted(colors.items()):
    print(f"  {color} → {var}")
