/**
 * filter_ajax.js - Version AJAX du système de filtrage
 *
 * OBJECTIF: Éviter les rechargements de page lors des changements de filtres/colonnes
 *
 * DIFFÉRENCES AVEC filter.js ORIGINAL:
 * 1. applyFilters() utilise fetch() au lieu de window.location.search
 * 2. Les colonnes sont chargées dynamiquement (lazy loading)
 * 3. La pagination est gérée en AJAX
 * 4. L'historique du navigateur est mis à jour sans rechargement
 *
 * UTILISATION:
 * 1. Inclure ce fichier APRÈS filter.js dans le template
 * 2. Ajouter l'attribut data-ajax-mode="true" sur le body pour activer
 * 3. Les endpoints API doivent être disponibles: /inventory/api/servers/, /inventory/api/count/
 */

(function() {
    'use strict';

    // ==========================================================================
    // CONFIGURATION
    // ==========================================================================

    const CONFIG = {
        apiEndpoint: `/${window.appname || 'inventory'}/api/servers/`,
        countEndpoint: `/${window.appname || 'inventory'}/api/count/`,
        listboxEndpoint: `/${window.appname || 'inventory'}/api/listbox/`,
        debounceDelay: 300,  // ms avant d'appliquer les filtres
        loadingClass: 'loading',
        errorClass: 'error'
    };

    // ==========================================================================
    // STATE MANAGEMENT
    // ==========================================================================

    const state = {
        filters: {},
        visibleColumns: [],
        currentPage: 1,
        pageSize: 50,
        permanentFilter: 'All Servers',
        flatView: false,
        isLoading: false,
        abortController: null
    };

    // ==========================================================================
    // UTILITY FUNCTIONS
    // ==========================================================================

    /**
     * Debounce function pour éviter les appels multiples
     */
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    /**
     * Met à jour l'URL sans recharger la page
     */
    function updateURLWithoutReload(params) {
        const url = new URL(window.location);

        // Nettoyer les anciens paramètres de filtre
        const keysToRemove = [];
        url.searchParams.forEach((value, key) => {
            if (!key.startsWith('cat_') && key !== 'view') {
                keysToRemove.push(key);
            }
        });
        keysToRemove.forEach(key => url.searchParams.delete(key));

        // Ajouter les nouveaux paramètres
        for (const [key, value] of Object.entries(params)) {
            if (value && value.length > 0) {
                if (Array.isArray(value)) {
                    url.searchParams.set(key, value.join(','));
                } else {
                    url.searchParams.set(key, value);
                }
            }
        }

        // Mettre à jour l'historique
        history.replaceState(null, '', url.toString());
    }

    /**
     * Affiche un indicateur de chargement
     */
    function showLoading() {
        state.isLoading = true;
        const tableContainer = document.querySelector('.table-container');
        if (tableContainer) {
            tableContainer.classList.add(CONFIG.loadingClass);
        }

        // Désactiver les interactions
        document.querySelectorAll('.search-input, .listbox-centered, select').forEach(el => {
            el.disabled = true;
        });
    }

    /**
     * Cache l'indicateur de chargement
     */
    function hideLoading() {
        state.isLoading = false;
        const tableContainer = document.querySelector('.table-container');
        if (tableContainer) {
            tableContainer.classList.remove(CONFIG.loadingClass);
        }

        // Réactiver les interactions
        document.querySelectorAll('.search-input, .listbox-centered, select').forEach(el => {
            el.disabled = false;
        });
    }

    /**
     * Affiche une erreur
     */
    function showError(message) {
        console.error('AJAX Filter Error:', message);

        const errorDiv = document.createElement('div');
        errorDiv.className = 'ajax-error-message';
        errorDiv.innerHTML = `
            <span class="error-icon">⚠️</span>
            <span class="error-text">${message}</span>
            <button onclick="this.parentElement.remove()">×</button>
        `;

        const container = document.querySelector('.main-content');
        if (container) {
            container.insertBefore(errorDiv, container.firstChild);

            // Auto-remove après 5 secondes
            setTimeout(() => errorDiv.remove(), 5000);
        }
    }

    // ==========================================================================
    // API CALLS
    // ==========================================================================

    /**
     * Récupère les données des serveurs via l'API
     */
    async function fetchServers() {
        // Annuler la requête précédente si elle existe
        if (state.abortController) {
            state.abortController.abort();
        }
        state.abortController = new AbortController();

        const params = new URLSearchParams();

        // Ajouter les filtres
        for (const [key, values] of Object.entries(state.filters)) {
            if (values && values.length > 0) {
                params.set(key, values.join(','));
            }
        }

        // Ajouter les paramètres de pagination
        params.set('page', state.currentPage);
        params.set('page_size', state.pageSize);

        // Ajouter les colonnes visibles
        if (state.visibleColumns.length > 0) {
            params.set('visible_columns', state.visibleColumns.join(','));
        }

        // Ajouter le filtre permanent
        params.set('permanentfilter', state.permanentFilter);

        // Mode d'affichage
        if (state.flatView) {
            params.set('view', 'flat');
        }

        try {
            const response = await fetch(`${CONFIG.apiEndpoint}?${params}`, {
                signal: state.abortController.signal,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();

        } catch (error) {
            if (error.name === 'AbortError') {
                console.log('Request aborted');
                return null;
            }
            throw error;
        }
    }

    /**
     * Récupère le compte total de serveurs
     */
    async function fetchServerCount() {
        const params = new URLSearchParams();

        for (const [key, values] of Object.entries(state.filters)) {
            if (values && values.length > 0) {
                params.set(key, values.join(','));
            }
        }

        params.set('permanentfilter', state.permanentFilter);

        try {
            const response = await fetch(`${CONFIG.countEndpoint}?${params}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            return await response.json();

        } catch (error) {
            console.error('Error fetching count:', error);
            return null;
        }
    }

    // ==========================================================================
    // DOM UPDATES
    // ==========================================================================

    /**
     * Met à jour le tableau avec les nouvelles données
     */
    function updateTable(data) {
        const tbody = document.querySelector('#serversTable tbody');
        if (!tbody) return;

        // Vider le tbody
        tbody.innerHTML = '';

        if (!data.servers || data.servers.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="${state.visibleColumns.length + 2}" style="text-align: center; padding: 40px; color: #6c757d;">
                        No servers found.
                    </td>
                </tr>
            `;
            return;
        }

        // Générer les lignes
        for (const server of data.servers) {
            const tr = document.createElement('tr');
            tr.className = 'server-row primary-row';
            tr.dataset.hostname = server.hostname || server.SERVER_ID;

            // Colonne expand (+/-)
            const tdExpand = document.createElement('td');
            tdExpand.className = 'col-expand sticky-col-1';
            if (server.count > 1) {
                tdExpand.innerHTML = `<button class="expand-btn" onclick="toggleDetails('${server.hostname}')">+</button>`;
            }
            tr.appendChild(tdExpand);

            // Colonne count (#)
            const tdCount = document.createElement('td');
            tdCount.className = 'col-info sticky-col-2';
            tdCount.innerHTML = `<span class="instance-count">${server.count || 1}</span>`;
            tr.appendChild(tdCount);

            // Colonnes de données
            for (const col of state.visibleColumns) {
                const td = document.createElement('td');
                td.className = `${col} field-value`;

                if (col === 'SERVER_ID') {
                    td.classList.add('hostname-cell', 'sticky-col-3');
                    td.innerHTML = `<strong>${server[col] || server.hostname || '-'}</strong>`;
                } else {
                    const value = server[col];
                    const isVariable = server[`${col}_is_variable`];

                    if (isVariable) {
                        td.innerHTML = `<span class="variable-field">${value || '-'}</span>`;
                    } else {
                        td.textContent = value || '-';
                    }
                }

                tr.appendChild(td);
            }

            tbody.appendChild(tr);
        }
    }

    /**
     * Met à jour la pagination
     */
    function updatePagination(data) {
        const paginationDiv = document.querySelector('.pagination .step-links');
        if (!paginationDiv) return;

        let html = '';

        if (data.has_previous) {
            html += `<a href="#" onclick="ajaxGoToPage(1); return false;">&laquo; First</a> `;
            html += `<a href="#" onclick="ajaxGoToPage(${data.current_page - 1}); return false;">Previous</a> `;
        }

        html += `<span class="current">Page ${data.current_page} of ${data.total_pages}</span>`;

        if (data.has_next) {
            html += ` <a href="#" onclick="ajaxGoToPage(${data.current_page + 1}); return false;">Next</a>`;
            html += ` <a href="#" onclick="ajaxGoToPage(${data.total_pages}); return false;">Last &raquo;</a>`;
        }

        paginationDiv.innerHTML = html;
    }

    /**
     * Met à jour le compteur total
     */
    function updateTotalCount(data) {
        const totalDiv = document.querySelector('#totalRecords span');
        if (totalDiv && data.total_count !== undefined) {
            totalDiv.textContent = data.total_count;
        }
    }

    /**
     * Met à jour les filtres visuels (tags)
     */
    function updateFilterTags() {
        const filterTagsDiv = document.getElementById('filterTags');
        if (!filterTagsDiv) return;

        filterTagsDiv.innerHTML = '';

        for (const [column, values] of Object.entries(state.filters)) {
            for (const value of values) {
                const tag = document.createElement('span');
                tag.className = 'filter-tag';
                tag.dataset.column = column;
                tag.dataset.term = value;
                tag.innerHTML = `${column}: ${value} <span class="remove-tag" onclick="ajaxRemoveFilter('${column}', '${value}')">x</span>`;
                filterTagsDiv.appendChild(tag);
            }
        }
    }

    // ==========================================================================
    // MAIN AJAX FUNCTIONS (Public API)
    // ==========================================================================

    /**
     * Applique les filtres via AJAX
     * Remplace l'ancienne fonction qui faisait un rechargement complet
     */
    async function applyFiltersAjax() {
        if (state.isLoading) return;

        showLoading();

        try {
            const data = await fetchServers();

            if (data === null) {
                // Request was aborted
                return;
            }

            // Mettre à jour l'interface
            updateTable(data);
            updatePagination(data);
            updateTotalCount(data);
            updateFilterTags();

            // Mettre à jour l'URL sans recharger
            updateURLWithoutReload({
                ...state.filters,
                page: state.currentPage,
                page_size: state.pageSize,
                visible_columns: state.visibleColumns,
                permanentfilter: state.permanentFilter,
                view: state.flatView ? 'flat' : ''
            });

        } catch (error) {
            showError(`Failed to load servers: ${error.message}`);
        } finally {
            hideLoading();
        }
    }

    // Version debounced pour les inputs
    const applyFiltersDebounced = debounce(applyFiltersAjax, CONFIG.debounceDelay);

    /**
     * Ajoute un filtre
     */
    function addFilter(column, value) {
        const normalizedValue = value.toUpperCase().trim();

        if (!state.filters[column]) {
            state.filters[column] = [];
        }

        if (!state.filters[column].includes(normalizedValue)) {
            state.filters[column].push(normalizedValue);
            state.currentPage = 1;  // Reset à la page 1
            applyFiltersDebounced();
        }
    }

    /**
     * Supprime un filtre
     */
    function removeFilter(column, value) {
        if (state.filters[column]) {
            state.filters[column] = state.filters[column].filter(v => v !== value);
            if (state.filters[column].length === 0) {
                delete state.filters[column];
            }
            state.currentPage = 1;
            applyFiltersAjax();
        }
    }

    /**
     * Efface tous les filtres
     */
    function clearAllFilters() {
        state.filters = {};
        state.currentPage = 1;
        applyFiltersAjax();
    }

    /**
     * Change de page
     */
    function goToPage(pageNumber) {
        state.currentPage = parseInt(pageNumber);
        applyFiltersAjax();
    }

    /**
     * Change la taille de page
     */
    function setPageSize(size) {
        state.pageSize = parseInt(size);
        state.currentPage = 1;
        applyFiltersAjax();
    }

    /**
     * Toggle une colonne visible
     */
    function toggleColumn(column, visible) {
        if (visible && !state.visibleColumns.includes(column)) {
            state.visibleColumns.push(column);
        } else if (!visible) {
            state.visibleColumns = state.visibleColumns.filter(c => c !== column);
        }
        applyFiltersAjax();
    }

    /**
     * Change le filtre permanent
     */
    function setPermanentFilter(filterName) {
        state.permanentFilter = filterName;
        state.currentPage = 1;
        applyFiltersAjax();
    }

    // ==========================================================================
    // INITIALIZATION
    // ==========================================================================

    /**
     * Initialise le mode AJAX si activé
     */
    function initAjaxMode() {
        // Vérifier si le mode AJAX est activé
        const body = document.body;
        if (!body.dataset.ajaxMode && !window.ajaxModeEnabled) {
            console.log('AJAX mode not enabled. Using standard filter.js');
            return false;
        }

        console.log('Initializing AJAX filter mode...');

        // Récupérer l'état initial depuis l'URL
        const urlParams = new URLSearchParams(window.location.search);

        // Reconstruire les filtres depuis l'URL
        const json_data = window.jsonData || JSON.parse(document.getElementById('json-data')?.textContent || '{}');

        for (const [key, value] of urlParams.entries()) {
            if (!['page', 'page_size', 'visible_columns', 'permanentfilter', 'view', 'scrollLeft'].includes(key) &&
                !key.startsWith('cat_')) {
                state.filters[key] = value.split(',').map(v => v.trim().toUpperCase());
            }
        }

        // Pagination
        state.currentPage = parseInt(urlParams.get('page')) || 1;
        state.pageSize = parseInt(urlParams.get('page_size')) || 50;

        // Colonnes visibles
        const visibleCols = urlParams.get('visible_columns');
        if (visibleCols) {
            state.visibleColumns = visibleCols.split(',').filter(c => c);
        } else {
            // Colonnes par défaut depuis les checkboxes
            state.visibleColumns = Array.from(document.querySelectorAll('.column-checkbox:checked'))
                .map(cb => cb.dataset.column);
        }

        // Filtre permanent
        state.permanentFilter = urlParams.get('permanentfilter') || 'All Servers';

        // Mode d'affichage
        state.flatView = urlParams.get('view') === 'flat';

        // Remplacer les event handlers
        overrideEventHandlers();

        console.log('AJAX mode initialized with state:', state);
        return true;
    }

    /**
     * Remplace les event handlers existants par les versions AJAX
     */
    function overrideEventHandlers() {
        // Override handleInput pour les search inputs
        const searchInputs = document.querySelectorAll('.search-input');
        searchInputs.forEach(input => {
            // Supprimer les anciens handlers
            const newInput = input.cloneNode(true);
            input.parentNode.replaceChild(newInput, input);

            // Ajouter le nouveau handler
            newInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter' && e.target.value.trim() !== '') {
                    e.preventDefault();
                    const column = e.target.name;
                    const terms = e.target.value.trim().split(',').map(t => t.trim());

                    terms.forEach(term => {
                        if (term) addFilter(column, term);
                    });

                    e.target.value = '';
                }
            });
        });

        // Override listbox handlers
        const listboxes = document.querySelectorAll('[id$="-listbox"]');
        listboxes.forEach(listbox => {
            const newListbox = listbox.cloneNode(true);
            listbox.parentNode.replaceChild(newListbox, listbox);

            newListbox.addEventListener('change', function() {
                if (this.value) {
                    const baseName = this.id.replace('-listbox', '');
                    addFilter(baseName, '@' + this.value);
                    this.value = '';
                }
            });
        });

        // Override page_size selector
        const pageSizeSelect = document.getElementById('page_size');
        if (pageSizeSelect) {
            pageSizeSelect.onchange = function() {
                setPageSize(this.value);
            };
        }

        // Override column checkboxes
        const columnCheckboxes = document.querySelectorAll('.column-checkbox');
        columnCheckboxes.forEach(cb => {
            cb.addEventListener('change', function() {
                toggleColumn(this.dataset.column, this.checked);
            });
        });

        // Override clear filters button
        const clearBtn = document.getElementById('clearFiltersButton');
        if (clearBtn) {
            clearBtn.onclick = clearAllFilters;
        }
    }

    // ==========================================================================
    // EXPOSE PUBLIC API
    // ==========================================================================

    // Fonctions accessibles globalement
    window.ajaxApplyFilters = applyFiltersAjax;
    window.ajaxAddFilter = addFilter;
    window.ajaxRemoveFilter = removeFilter;
    window.ajaxClearFilters = clearAllFilters;
    window.ajaxGoToPage = goToPage;
    window.ajaxSetPageSize = setPageSize;
    window.ajaxToggleColumn = toggleColumn;
    window.ajaxSetPermanentFilter = setPermanentFilter;
    window.ajaxFilterState = state;

    // Initialiser au chargement
    document.addEventListener('DOMContentLoaded', function() {
        // Attendre un peu pour que filter.js soit chargé
        setTimeout(() => {
            if (initAjaxMode()) {
                // Mode AJAX activé - remplacer applyFilters global
                window.applyFilters = applyFiltersAjax;
            }
        }, 100);
    });

})();

/*
 * STYLES CSS À AJOUTER (dans inventory.css)
 *
 * .table-container.loading {
 *     opacity: 0.5;
 *     pointer-events: none;
 *     position: relative;
 * }
 *
 * .table-container.loading::after {
 *     content: '';
 *     position: absolute;
 *     top: 50%;
 *     left: 50%;
 *     width: 40px;
 *     height: 40px;
 *     margin: -20px 0 0 -20px;
 *     border: 4px solid #f3f3f3;
 *     border-top: 4px solid #3498db;
 *     border-radius: 50%;
 *     animation: spin 1s linear infinite;
 * }
 *
 * @keyframes spin {
 *     0% { transform: rotate(0deg); }
 *     100% { transform: rotate(360deg); }
 * }
 *
 * .ajax-error-message {
 *     background: #fee;
 *     border: 1px solid #f00;
 *     padding: 10px 15px;
 *     border-radius: 4px;
 *     margin-bottom: 10px;
 *     display: flex;
 *     align-items: center;
 *     gap: 10px;
 * }
 *
 * .ajax-error-message button {
 *     margin-left: auto;
 *     background: none;
 *     border: none;
 *     font-size: 18px;
 *     cursor: pointer;
 * }
 */
