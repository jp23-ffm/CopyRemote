"""
urls_optimized.py - URLs avec les nouveaux endpoints API AJAX

NOUVEAUX ENDPOINTS pour filter_ajax.js:
- /api/servers/     -> Liste des serveurs (JSON, paginé, filtré)
- /api/count/       -> Compte rapide des serveurs
- /api/listbox/     -> Valeurs des listbox
- /api/columns/     -> Données des colonnes (lazy loading)

Pour utiliser cette version:
1. Renommer urls.py -> urls_original.py
2. Renommer urls_optimized.py -> urls.py
"""

from django.urls import path
from . import views
from . import views_optimized

app_name = 'inventory'

urlpatterns = [
    # =========================================================================
    # VUES PRINCIPALES (version optimisée)
    # =========================================================================
    path('', views_optimized.server_view, name='server_view'),
    path('servers/', views_optimized.server_view, name='server_view'),

    # =========================================================================
    # NOUVEAUX ENDPOINTS API AJAX (pour filter_ajax.js)
    # =========================================================================

    # API pour récupérer les serveurs (utilisé par filter_ajax.js)
    # GET /inventory/api/servers/?page=1&page_size=50&visible_columns=SERVER_ID,OSSHORTNAME&...
    path('api/servers/', views_optimized.api_servers, name='api_servers'),

    # API pour le compte rapide (sans charger les données)
    # GET /inventory/api/count/?[filters]
    path('api/count/', views_optimized.api_server_count, name='api_server_count'),

    # API pour les valeurs des listbox (dropdown) - utilisé aussi par l'ancienne version
    # GET /inventory/api/listbox/?columns=OSSHORTNAME,ENVIRONMENT
    path('api/listbox/', views_optimized.api_listbox_values, name='api_listbox_values'),
    path('api/listbox-values/', views_optimized.api_listbox_values, name='api_listbox_values_alt'),

    # API pour le lazy loading des colonnes
    # GET /inventory/api/columns/?columns=APP_NAME,REGION&hostnames=SRV001,SRV002
    path('api/columns/', views_optimized.api_column_data, name='api_column_data'),
    path('api/column-data/', views_optimized.api_column_data, name='api_column_data_alt'),

    # =========================================================================
    # ANNOTATIONS
    # =========================================================================
    path('annotation/<str:hostname>/', views.edit_annotation, name='edit_annotation'),

    # =========================================================================
    # RECHERCHES SAUVEGARDÉES
    # =========================================================================
    path('load_search/<int:search_id>/', views.load_search, name='load_search'),
    path('save_search/', views.save_search, name='save_search'),
    path('delete_search/<int:search_id>/', views.delete_search, name='delete_search'),

    # =========================================================================
    # EXPORT
    # =========================================================================
    path('export/<str:filetype>/', views.export_to_file, name='export_to_file'),
    path('export/grouped/<str:filetype>/', views.export_to_file_grouped, name='export_grouped'),
    path('export/status/<uuid:job_id>/<str:filetype>/', views.export_status, name='export_status'),
    path('export/download/<uuid:job_id>/<str:filetype>/', views.download_export, name='download_export'),

    # =========================================================================
    # AUTRES
    # =========================================================================
    path('update_permanentfilter_field/', views.update_permanentfilter_field, name='update_permanentfilter_field'),
    path('bulk_update/', views.servers_bulk_update, name='servers_bulk_update'),
    path('import_csv/', views.bulk_import_csv, name='bulk_import_csv'),
    path('logs_imports/', views.log_imports, name='logs_imports'),
    path('charts/', views.chart_view, name='chart_view'),
]
