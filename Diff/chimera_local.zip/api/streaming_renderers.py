import csv
import json
from django.http import StreamingHttpResponse
from rest_framework.renderers import BaseRenderer


class StreamingOneLinePerInstanceJSONRenderer(BaseRenderer):
    media_type = "application/json"
    format = "json"

    def render(self, data, accepted_media_type=None, renderer_context=None):
        """
        Returns an iterator that yields bytes.  The iterator is consumed by
        Django's StreamingHttpResponse.
        """
        if not isinstance(data, dict) or "results" not in data:
            # Fallback to normal dump for error pages etc.
            return json.dumps(data).encode(self.charset)

        def generator():
            # Opening wrapper
            yield b"{"
            # count field (you can add more fields here)
            count_part = f'"count":{data.get("count",0)},"results":['.encode(self.charset)
            yield count_part

            first = True
            for item in data["results"]:
                if not first:
                    yield b","
                else:
                    first = False
                # compact JSON for the single object
                line = json.dumps(item, separators=(",", ":"), ensure_ascii=False)
                # indent the line to align with the wrapper (4 spaces + 4 for "results")
                yield b"\n        " + line.encode(self.charset)

            # Closing brackets
            yield b"\n    ]}"
        return generator()


class CSVRenderer(BaseRenderer):
    media_type = 'text/csv'
    format = 'csv'

    def render(self, data, accepted_media_type=None, renderer_context=None):
        pseudo_buffer = Echo()
        writer = csv.writer(pseudo_buffer)
        response = StreamingHttpResponse(
            (writer.writerow(row) for row in data),
            content_type='text/csv'
        )
        response['Content-Disposition'] = 'attachment; filename="data.csv"'
        return response

class Echo:
    def write(self, value):
        return value
