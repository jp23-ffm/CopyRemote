from django.core.management.base import BaseCommand
from api.management.commands import status_checks as checks

class Command(BaseCommand):
    help = "Health checks"

    def handle(self, *args, **options):
        failed = False
        for name, fn in checks.CHECKS:
            try:
                result = fn()
                self.stdout.write(self.style.SUCCESS(f"[{name}] OK"))
            except checks.StatusCheckError as exc:
                failed = True
                self.stderr.write(self.style.ERROR(f"[{name}] ERROR: {exc}"))
        if failed:
            raise SystemExit(1)   # Exit with non‑zero code for CI pipelines

