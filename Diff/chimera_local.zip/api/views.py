import csv
import datetime
import json
import os
import time
from pathlib import Path
import sys

from django.apps import apps
from django.conf import settings
from django.http import StreamingHttpResponse, HttpResponse
from django.core.exceptions import FieldError, ValidationError
from django.db import connection
from django.db.models import Q
from django.db.models.functions import Lower, Upper
#from django.db.models.functions import Upper
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, status, generics
from rest_framework.filters import SearchFilter, OrderingFilter
from rest_framework.pagination import PageNumberPagination
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.renderers import JSONRenderer
from rest_framework.views import APIView

from businesscontinuity.models import Server as BCServer, ServerUnique
from reportapp.models import Server as ReportServer
from inventory.models import Server as InventoryServer
from monitor.views import get_cluster_status

from .custom_filters import DynamicFilterBackend
from .serializers import ServerSerializer, LimitedServerSerializer, GenericQuerySerializer, SrvPropSerializer, BusinessContinuitySerializer, InventoryServerSerializer

from .streaming_renderers import CSVRenderer, Echo,  StreamingOneLinePerInstanceJSONRenderer

from api.management.commands import status_checks as checks


field_app_mapping = {
    'reportapp': ReportServer,
    'inventory': InventoryServer,
    'businesscontinuity': BCServer
}

class ModelFieldsContentView(APIView):
    def get_field_mapping(self, app):
        current_dir = os.path.dirname(__file__)
        fields_labels_file = os.path.join(current_dir, f'../{app}/field_labels.json')
        try:
            with open(fields_labels_file, 'r') as f:
                fields_labels = json.load(f)
        except FileNotFoundError:
            return {'error': f'Field labels file not found for app {app}'}
        except PermissionError:
            return {'error': f'Permission denied when trying to read field labels file for app {app}'}
        except json.JSONDecodeError:
            return {'error': f'Invalid JSON in field labels file for app {app}'}
        except Exception as e:
            return {'error': str(e)}

        if 'api_ModelFieldsContentView_allowed' in fields_labels:
            allowed_fields = fields_labels['api_ModelFieldsContentView_allowed']
            if app == 'businesscontinuity':
                return {field: 'server_unique__' + field if 'model_extra' in fields_labels['fields'].get(field, {}) else field for field in allowed_fields}
            else:
                return {field: field for field in allowed_fields}
        else:
            allowed_fields = {properties['inputname']: 'server_unique__' + field if app == 'businesscontinuity' and 'model_extra' in properties else field 
                              for field, properties in fields_labels['fields'].items() if 'listbox' in properties}
            return allowed_fields

    def get(self, request, app):
        try:
            model = field_app_mapping[app]
        except LookupError:
            return Response({'error': 'Model not found'}, status=404)
        field_name = request.GET.get('field')
        field_mapping = self.get_field_mapping(app)
        allowed_fields = list(field_mapping.values())

        if not field_name in allowed_fields:
            return Response({'error': 'Field not allowed for query'}, status=404)

        try:
            unique_values = set(model.objects.values_list(field_name, flat=True))
        except KeyError:
            return Response({'error': 'Field not found in mapping'}, status=404)
        except FieldError as e:
            return Response({'error': f'Field not found in model: {str(e)}'}, status=404)
        except Exception as e:
            return Response({'error': str(e)}, status=500)
            
        return Response({field_name: unique_values})


class ModelFieldsMappingView(APIView):
    
    def get_field_mapping(self, app):
        current_dir = os.path.dirname(__file__)
        fields_labels_file = os.path.join(current_dir, f'../{app}/field_labels.json')
        try:
            with open(fields_labels_file, 'r') as f:
                fields_labels = json.load(f)
        except FileNotFoundError:
            return {'error': f'Field labels file not found for app {app}'}
        except PermissionError:
            return {'error': f'Permission denied when trying to read field labels file for app {app}'}
        except json.JSONDecodeError:
            return {'error': f'Invalid JSON in field labels file for app {app}'}
        except Exception as e:
            return {'error': str(e)}

        field_mapping = {}
        for field, properties in fields_labels['fields'].items():
            if app == 'businesscontinuity' and 'model_extra' in properties:
                field_mapping[properties['inputname']] = 'server_unique__' + field
            else:
                field_mapping[properties['inputname']] = field
        return field_mapping

    def get(self, request, app):
        try:
            model = field_app_mapping[app]
        except KeyError:
            return Response({'error': 'Model not found'}, status=404)
        field_name = request.GET.get('field')
        field_mapping = self.get_field_mapping(app)
        if 'error' in field_mapping:
            return Response(field_mapping, status=500)

        return Response({v: k for k, v in field_mapping.items()})


class ServerViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = ReportServer.objects.all()
    serializer_class = LimitedServerSerializer
    #filter_backends = [SearchFilter, DjangoFilterBackend] 
    #search_fields = ['SERVER_ID', 'PAMELA_COUNTRY', 'PAMELA_OSSHORTNAME']
    #filterset_fields = ['SERVER_ID', 'PAMELA_COUNTRY', 'PAMELA_OSSHORTNAME']

    def get_queryset(self):
        query_params = self.request.query_params
        relevant_params = ['SERVER_ID', 'PAMELA_COUNTRY', 'PAMELA_OSSHORTNAME']

        # Initialize the empty Q object
        query_filter = Q()

        # Add wildcard-based filters
        for param in relevant_params:
            if param in query_params and query_params[param]:
                values = query_params[param].split(',')
                or_conditions = Q()
                for value in values:
                    value_pattern = value.replace('*', '.*').upper()
                    or_conditions |= Q(**{f"{param}__iregex": rf"^{value_pattern}$"})
                query_filter &= or_conditions

        # Add search term if present
        search_term = query_params.get('search', None)
        if search_term:
            search_conditions = Q()
            for field in ['SERVER_ID', 'PAMELA_COUNTRY', 'PAMELA_OSSHORTNAME']:  # Specify the fields to search
                search_conditions |= Q(**{f"{field}__icontains": search_term})
            query_filter &= search_conditions

        # Check if any query parameter is present but empty
        if any(param in query_params and not query_params[param] for param in relevant_params + ['search']):
            return ReportServer.objects.none()

        # Apply the constructed Q object to the queryset
        queryset = ReportServer.objects.filter(query_filter)

        return queryset
        

class ServerDetailViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ServerSerializer
    filter_backends = [SearchFilter, DjangoFilterBackend, OrderingFilter]
    filterset_fields = '__all__' #['name', 'is_active']
    search_fields = ['SERVER_ID', 'PAMELA_COUNTRY','PAMELA_OSSHORTNAME']
    #ordering_fields = ['SERVER_ID', 'SERVER_IP_VALUE']

    def get_queryset(self):
        query_params = self.request.query_params

        # Check if any query parameter is present but empty
        if any(value == '' for value in query_params.values()):
            return ReportServer.objects.none()

        # Check if any query parameter is present
        if not query_params:
            return ReportServer.objects.none()

        return ReportServer.objects.all()
        
        
class ServerMultiViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = ServerSerializer
    filter_backends = [SearchFilter, DjangoFilterBackend, OrderingFilter, DynamicFilterBackend]
    filterset_fields = ['SERVER_ID', 'PAMELA_COUNTRY']  # Specify the exact fields for filtering
    search_fields = ['SERVER_ID', 'PAMELA_COUNTRY']  # Specify the exact fields for searching
    ordering_fields = ['SERVER_ID', 'PAMELA_COUNTRY']

    def get_queryset(self):
        if not self.request.query_params:
            return ReportServer.objects.none()
        return ReportServer.objects.all()
        
        
class GetJsonEndpoint(APIView):
    
    def get(self, request, format=None):
        file_path = '/home/PREVOSTJ/data/businesscontinuity.json'

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return Response(data)

        except FileNotFoundError:
            error_data = {'Error': 'JSON file not found.'}
            return Response(error_data, status=status.HTTP_404_NOT_FOUND)
            
        except json.JSONDecodeError:
            error_data = {'Error': 'JSON file not correctly encoded.'}
            return Response(error_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


def validate_json_data(data, serializer):

    # Validate the JSON data against the serializer fields.

    allowed_keys = set(serializer().fields.keys())
    for key in data:
        if key not in allowed_keys:
            raise ValueError(f"Invalid key '{key}' in JSON data. Allowed keys are: {', '.join(allowed_keys)}")

            
class GenericQueryView(APIView):
    
    def post(self, request):
        try:
        
            # Validate JSON data
            try:
                validate_json_data(request.data, GenericQuerySerializer)
            except ValueError as e:
                return Response({"Error": str(e)}, status=status.HTTP_400_BAD_REQUEST)
                        
            serializer = GenericQuerySerializer(data=request.data)
            if not serializer.is_valid():
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            index_name = serializer.validated_data["index"]
            filters = serializer.validated_data.get("filters", {})
            fields = serializer.validated_data.get("fields", None)
            excludefields = serializer.validated_data.get("excludefields", None)
            default_exclude = ['id'] # Specify fields to be excluded by default

            if index_name == "reportapp":
                index_cls = ReportServer
                output_serializer = ServerSerializer
            elif index_name == "businesscontinuity":
                index_cls = BCServer
                output_serializer = BusinessContinuitySerializer
            else:
                return Response({"Error": f"Unsupported index: {index_name}"}, status=status.HTTP_400_BAD_REQUEST)

            invalid_filters = [fil for fil in filters if not hasattr(index_cls, fil) and not hasattr(ServerUnique, fil.split('__')[1])]
            if invalid_filters:
                return Response({"Error": f"Invalid fields for {index_name} index: {', '.join(invalid_filters)}"}, status=status.HTTP_400_BAD_REQUEST)

            queryset = index_cls.objects.filter(**filters)
            output_serializer_instance = output_serializer(queryset, many=True, fields=fields, excludefields=excludefields, default_exclude=default_exclude)
            return Response(output_serializer_instance.data, status=status.HTTP_200_OK)
            
            """
            # Adjust instance initialization with fields, exclude, and default_exclude params
            serialized_data = output_serializer(queryset, many=True, fields=fields, excludefields=excludefields, default_exclude=default_exclude).data
            # Join each serialized object with a newline to form JSON Lines
            json_lines = '\n'.join(json.dumps(item) for item in serialized_data)
            return Response(json_lines, status=status.HTTP_200_OK)
            """
            
        except Exception as e:
            error_data = {'Unexpected Error': f"{e}"}
            return Response(error_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            


class ServerPagination(PageNumberPagination):
    page_size = 100
    page_size_query_param = 'page_size'
    max_page_size = 200


def api_log(text):
    unix_ts = time.time()
    currenttime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(unix_ts))
    with open("/tmp/api.log", mode="a", encoding="utf-8") as file:
        file.write(f"{currenttime} {text}\n")


class SrvPropView(APIView):
    renderer_classes = [JSONRenderer, CSVRenderer]
    pagination_class = ServerPagination

    STREAMING_THRESHOLD = 200   # Threshold to use to switch to the streaming option
    STREAMING_CHUNK_SIZE = 10000  # Nb of chunks for the streaming

    MAX_RESULTS = 2000000
    MAX_FILTER_FIELDS = 15  # Max fields allowed in the filter
    MAX_FILTER_VALUES_PER_FIELD = 15000  # Max values per field allowed in the filter

    def post(self, request):
        try:
            # Validate JSON data

            api_log("------------------------")
            api_log(f"User: {request.user}")
            api_log(f"Payload: {request.data}")
            
            serializer = SrvPropSerializer(data=request.data)
            if not serializer.is_valid():
                api_log(f"Error: {serializer.errors}")            
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


            index_name = serializer.validated_data["index"]
            filters = serializer.validated_data.get("filters", {})
            fields = serializer.validated_data.get("fields", None)
            excludefields = serializer.validated_data.get("excludefields", None)
            default_exclude = ['id']  # Specify fields to be excluded by default
            output_format = serializer.validated_data.get("format", "json")  # Default to JSON

            if len(filters) == 0:
                api_log(f"Error: The field 'filters' can't be empty")
                return Response({
                    "error": f"The field 'filters' can't be empty"
                }, status=400)

            if len(filters) > self.MAX_FILTER_FIELDS:
                api_log(f"Error: Too many fields filters: {len(filters)} (max: {self.MAX_FILTER_FIELDS})")
                return Response({
                    "error": f"Too many fields filters: {len(filters)} (max: {self.MAX_FILTER_FIELDS})"
                }, status=400)

            for field, values in filters.items():
                if len(values) > self.MAX_FILTER_VALUES_PER_FIELD:
                    api_log(f"Error: Too many values for '{field}': {len(values)} (max: {self.MAX_FILTER_VALUES_PER_FIELD})")                
                    return Response({
                        "error": f"Too many values for '{field}': {len(values)} (max: {self.MAX_FILTER_VALUES_PER_FIELD})"
                    }, status=400)

            if index_name == "reportapp":
                index_cls = ReportServer
                output_serializer = ServerSerializer
            elif index_name == "businesscontinuity":
                index_cls = BCServer
                output_serializer = BusinessContinuitySerializer
            elif index_name == "inventory":
                index_cls = InventoryServer
                output_serializer = InventoryServerSerializer
            else:
                api_log(f"Error: Unsupported index: {index_name}")  
                return Response({"Error": f"Unsupported index: {index_name}"}, status=status.HTTP_400_BAD_REQUEST)

            # Map aliases to actual field names
            alias_map = {
                'priority_asset': 'server_unique__priority_asset',
                'in_live_play': 'server_unique__in_live_play',
                'action_during_lp': 'server_unique__action_during_lp',
                'original_action_during_lp': 'server_unique__original_action_during_lp',
                'cluster': 'server_unique__cluster',
                'cluster_type': 'server_unique__cluster_type'
            }

            mapped_filters = {}
            for key, value in filters.items():
                mapped_key = alias_map.get(key, key)
                mapped_filters[mapped_key] = value

            invalid_filters = [
                fil for fil in mapped_filters
                if not hasattr(index_cls, fil.split('__')[0])
                and not hasattr(BCServer, fil.split('__')[1] if '__' in fil else '')
            ]

            if invalid_filters:
                api_log(f"Error: Invalid fields for {index_name} index: {', '.join(invalid_filters)}")              
                return Response(
                    {
                        "Error": f"Invalid fields for {index_name} index: {', '.join(invalid_filters)}"
                    },
                    status=status.HTTP_400_BAD_REQUEST
                )

            # Determine the fields to use for distinct
            if fields is None:
                excludefields = excludefields or []
                distinct_fields = [field.name for field in index_cls._meta.fields if field.name not in default_exclude and field.name not in excludefields]
            else:
                distinct_fields = fields

            queryset = index_cls.objects.all()

            """
            # Pre filter on SERVER_ID if present
            server_id_field = None
            for f in mapped_filters.keys():
                if f.lower() in ("server_sid"):
                    server_id_field = f
                    break

            if server_id_field and mapped_filters[server_id_field]:  # Treat the SERVER_ID case
                values = mapped_filters.pop(server_id_field)
                has_wildcards = any('*' in v for v in values)

                if has_wildcards:
                    # Wildcards (*)
                    or_conditions = Q()
                    for value in values:
                        pattern = value.replace('*', '.*')
                        or_conditions |= Q(**{f"{server_id_field}__iregex": f"^{pattern}$"})
                    queryset = queryset.filter(or_conditions)
                else:
                    # __in case-insensitive
                    lowered_values = [v.lower() for v in values]
                    queryset = queryset.annotate(server_id_lower=Lower(server_id_field)).filter(
                        server_id_lower__in=lowered_values
                    )

                # Nothing found, exit
                if not queryset.exists():
                    return Response([], status=status.HTTP_200_OK)
            """


            # Construction of the global filter for the other fields
            query_filter = Q()
            lower_annotations = {}

            for field, values in mapped_filters.items():
                if not values:
                    continue

                has_wildcards = any('*' in v for v in values)

                if has_wildcards:
                    or_conditions = Q()
                    for value in values:
                        value_pattern = value.replace('*', '.*')
                        or_conditions |= Q(**{f"{field}__iregex": f"^{value_pattern}$"})
                    # Combine the or_conditions with the query_filter
                    query_filter &= or_conditions
                else:
                    # Standard case : __in is case insensitive
                    lowered_values = [v.lower() for v in values]
                    lower_field_name = f"{field}_lower"
                    lower_annotations[lower_field_name] = Lower(field)
                    # Combine the Q object with the query_filter
                    query_filter &= Q(**{f"{lower_field_name}__in": lowered_values})

            # Apply the filters, use *distinct_fields on PostgreSQL
            if lower_annotations:
                #queryset = queryset.annotate(**lower_annotations).filter(query_filter).distinct()
                queryset = queryset.annotate(**lower_annotations).filter(query_filter).distinct(*distinct_fields).order_by(*distinct_fields)
            else:
                #queryset = queryset.filter(query_filter).distinct()
                queryset = queryset.filter(query_filter).distinct(*distinct_fields).order_by(*distinct_fields)

            count = queryset.count()

            if count > self.MAX_RESULTS:
                api_log(f"Error: Too many results: {count} (maximum: {self.MAX_RESULTS})")                
                return Response({
                    "error": f"Too many results: {count} (maximum: {self.MAX_RESULTS})",
                    "hint": "Please refine your filters to reduce the number of results",
                    "count": count
                }, status=status.HTTP_400_BAD_REQUEST)

            if request.GET.get('page'):
                api_log(f"Using the Paging Mode")
                # Pagination mode requested
                paginator = ServerPagination()
                page = paginator.paginate_queryset(queryset, request)

                if page is not None:
                    serializer_instance = output_serializer(
                        page, many=True,
                        fields=fields,
                        excludefields=excludefields,
                        default_exclude=default_exclude
                    )

                    if output_format == "csv":
                        csv_response = self._generate_csv_response(
                            queryset=page,
                            serializer_class=output_serializer,
                            fields=fields,
                            excludefields=excludefields,
                            default_exclude=default_exclude
                        )
                        return csv_response
                    else:
                        return paginator.get_paginated_response(serializer_instance.data)

            # Big amount -> Streaming
            elif count > self.STREAMING_THRESHOLD:
                api_log(f"Nb items: {count} - Using the Streaming Mode")  
                if output_format == "csv":
                    return self._stream_csv_response(
                        queryset=queryset,
                        serializer_class=output_serializer,
                        fields=fields,
                        excludefields=excludefields,
                        default_exclude=default_exclude
                    )
                else:
                    return self._stream_json_response(
                        queryset=queryset,
                        serializer_class=output_serializer,
                        count=count,
                        fields=fields,
                        excludefields=excludefields,
                        default_exclude=default_exclude
                    )

            # Small amount -> Normal
            else:
                api_log(f"Nb items: {count} - Using the Normal Mode")             
                if output_format == "csv":
                    return self._generate_csv_response(
                        queryset=queryset,
                        serializer_class=output_serializer,
                        fields=fields,
                        excludefields=excludefields,
                        default_exclude=default_exclude
                    )
                else:
                    output_serializer_instance = output_serializer(
                        queryset,
                        many=True,
                        fields=fields,
                        excludefields=excludefields,
                        default_exclude=default_exclude
                    )

                    response_data = {
                        "count": count,
                        "results": output_serializer_instance.data
                    }

                    return Response(response_data, status=status.HTTP_200_OK)

        except Exception as e:
            error_data = {"Unexpected Error": f"{e}"}
            api_log(f"Error: {e}")
            return Response(error_data, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        finally:
            api_log("End")

    def _stream_csv_response(self, queryset, serializer_class, fields, excludefields,
                            default_exclude):
        """
        Stream CSV response optimised
        - Header only once
        - Serialization by batch (many=True)
        """
        def generate():
            """Generator to yield the CSV chunk by chunk"""
            pseudo_buffer = Echo()
            writer = csv.writer(pseudo_buffer)

            # Write the header Once only
            first_obj = queryset.first()
            if first_obj:
                header_serializer = serializer_class(
                    first_obj, 
                    fields=fields, 
                    excludefields=excludefields, 
                    default_exclude=default_exclude
                )
                header = header_serializer.data.keys()
                yield writer.writerow(header)

            # iterator() with chunk_size avoids to load everything in RAM
            offset = 0
            while True:
                batch = list(queryset[offset:offset + self.STREAMING_CHUNK_SIZE])
                
                if not batch:
                    break
                
                # Serialize le batch entier (many=True) - OPTIMISÉ
                serializer = serializer_class(
                    batch,
                    many=True,
                    fields=fields,
                    excludefields=excludefields,
                    default_exclude=default_exclude
                )
                
                # Convert to CSV and send
                for data in serializer.data:
                    yield writer.writerow(data.values())
                
                offset += self.STREAMING_CHUNK_SIZE

        # Create the streaming response
        response = StreamingHttpResponse(generate(), content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="data.csv"'
        return response


    def _generate_csv_response(self, queryset, serializer_class, fields, excludefields,
                               default_exclude):
        # Generate CSV response without streaming (small volume)

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="data.csv"'
        writer = csv.writer(response)

        # Write the header
        if isinstance(queryset, list):
            serializer = serializer_class(
                queryset[0], 
                fields=fields, 
                excludefields=excludefields, 
                default_exclude=default_exclude
            )
        else:
            serializer = serializer_class(
                queryset.first(), 
                fields=fields, 
                excludefields=excludefields, 
                default_exclude=default_exclude
            )
        header = serializer.data.keys()
        writer.writerow(header)

        serializer_instance = serializer_class(
            queryset, 
            many=True, 
            fields=fields,
            excludefields=excludefields, 
            default_exclude=default_exclude
        )
        serialized_data = serializer_instance.data
        for data in serialized_data:
            writer.writerow(data.values())

        return response


    def _stream_json_response(self, queryset, serializer_class, count, fields,
                             excludefields, default_exclude):
        """
        Stream JSON response optimised
        - Count only once at beginning
        - Serialization by batch (many=True)
        - JSON format compliant
        """
        def generate():
            """Generator to yield the JSON chunk by chunk"""
            
            # Begin of the JSON - Count once only
            yield b'{"count": '
            yield str(count).encode('utf-8')
            yield b', "results": ['
            
            first = True
            
            # iterator() with chunk_size avoids to load everything in RAM
            offset = 0
            while True:
                # Charge the complete batch
                batch = list(queryset[offset:offset + self.STREAMING_CHUNK_SIZE])
                
                if not batch:
                    break
                
                # Serialize the entite batch (many=True) - OPTIMIZED
                serializer = serializer_class(
                    batch,
                    many=True,
                    fields=fields,
                    excludefields=excludefields,
                    default_exclude=default_exclude
                )
                
                # Convert to JSON and send
                for obj_data in serializer.data:
                    # Use comma as separator, except for the first one
                    if not first:
                        yield b','
                    first = False
                    
                    yield json.dumps(obj_data).encode('utf-8')
                
                offset += self.STREAMING_CHUNK_SIZE

            # End of JSON - Once only
            yield b']}'

        # Create the streaming response
        response = StreamingHttpResponse(
            generate(),
            content_type='application/json'
        )

        # Optional Headers for best compatibility
        response['X-Total-Count'] = str(count)
        response['Cache-Control'] = 'no-cache'
        return response


class HealthCheckView(APIView):
    permission_classes = []
    authentication_classes = []

    def get(self, request):
        if not request.META.get('REMOTE_ADDR') == '127.0.0.1':
            return HttpResponse('Forbidden', status=403)

        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT 1")
            return Response({'status': 'healthy'}, status=200)
        except:
            return Response({'status': 'unhealthy'}, status=503)


"""class StatusCheck(APIView):
    serializer_class = None
    def get_view_name(self):
        return "Chimera Status Checks"

    # List of the different checks to perform
    CHECKS = [
        ("database", lambda: checks.check_database(display_name="Database Check")),
        ("servers view", lambda: checks.count_table_items(app_label="reportapp", model_name="Server")),
        ("business continuity", lambda: checks.count_table_items(app_label="businesscontinuity", model_name="Server")),
        ("business continuity", lambda: checks.count_table_items(app_label="businesscontinuity", model_name="ServerUnique")),
        ("inventory", lambda: checks.count_table_items(app_label="inventory", model_name="Server")),
        ("inventory", lambda: checks.count_table_items(app_label="inventory", model_name="ServerGroupSummary")),
        ("disk", lambda: checks.check_disk(path="/", min_free_gb=1)),
        ("Business Continuity Last Import", lambda: checks.check_businesscontinuity_last_import()),
        ("Inventory Last Import", lambda: checks.check_inventory_last_import()),
        ("Check Certificate", lambda: checks.check_url_certificate(url="https://chimeraiaas.dev.echonet/login/"))
    ]

    def get(self, request, *args, **kwargs):
        results = []
        overall_status = "OK"

        for name, fn in self.CHECKS:
            try:
                result = fn()
                result.setdefault("Name", name)
                results.append(result)

                # Update overall_status based on the result status
                if result["Status"] == "Error":
                    overall_status = "Error"
                elif result["Status"] == "Warning" and overall_status != "Error":
                    overall_status = "Warning"

            except Exception as exc:
                overall_status = "Error"
                results.append({
                    "Status": "Error",
                    "Name": name,
                    "Error": f"Error during the execution: {exc}",
                })

        payload = {
            "Overall Status": overall_status,
            #"Timestamp": int(datetime.datetime.utcnow().timestamp()),
            "Checks": results,
        }

        http_status = status.HTTP_200_OK #if overall_status == "OK" else status.HTTP_503_SERVICE_UNAVAILABLE  # to change
        return Response(payload, status=http_status)
"""

class MonitorStatusView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        simple = request.GET.get('simple') == 'true'
        response, status = get_cluster_status(simple)
        return Response(response, status=status)
