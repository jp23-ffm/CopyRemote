import socket
from django.core.management.base import BaseCommand
from django.conf import settings
import monitor.management.commands.status_checks as checks
from monitor.models import HostHealthStatus


class Command(BaseCommand):
    help = 'Update the host status (host specific checks)'

    def add_arguments(self, parser):
        parser.add_argument(
            '--host-name',
            type=str,
            help='Host name',
        )

    def handle(self, *args, **options):
        # Get the host name
        host_name = options.get('host_name')
        if not host_name:
            host_name = getattr(settings, 'CURRENT_host_NAME', None)
        if not host_name:
            host_name = socket.gethostname()
        
        self.stdout.write(f"Update of the host status: {host_name}")
        
        hostname = socket.gethostname()
        ip_address = self._get_ip_address()
        version = getattr(settings, 'APP_VERSION', 'unknown')
        uptime = checks.check_system_uptime()
        
        # Host checks
        HOST_CHECKS = [
            ("Database Check", lambda: checks.check_database(display_name="Database")),
            #("Disk Space", lambda: checks.check_disk(path="/", min_free_gb=1)),
            ("Gunicorn Processes", lambda: checks.get_gunicorn(proc_expected=8)),
            ("nginx Processes", lambda: checks.get_nginx(proc_expected=4)),
            #("Django Processes", lambda: checks.print_django_stats(display_name="Django Processes", cpu_threshold=None, ram_threshold=None, display_total=False )),
        ]
        
        # Execute the checks
        checks_results = []
        overall_status = "OK"
        
        for check_name, check_fn in HOST_CHECKS:
            try:
                result = check_fn()
                checks_results.append(result)
                
                if result["Status"] == "Error":
                    overall_status = "Error"
                elif result["Status"] == "Warning" and overall_status != "Error":
                    overall_status = "Warning"
                    
            except Exception as exc:
                error_result = {
                    "Name": check_name,
                    "Status": "Error",
                    "Details": f"Exception: {str(exc)}"
                }
                checks_results.append(error_result)
                overall_status = "Error"
                self.stderr.write(self.style.ERROR(f"Error in check '{check_name}': {exc}"))
        
        # Sauvegarder en DB
        try:
            HostHealthStatus.update_host_status(
                host_name=host_name,
                status=overall_status,
                checks_data={
                    'checks': checks_results,
                    'total_checks': len(checks_results),
                    'ok_count': sum(1 for c in checks_results if c['Status'] == 'OK'),
                    'warning_count': sum(1 for c in checks_results if c['Status'] == 'Warning'),
                    'error_count': sum(1 for c in checks_results if c['Status'] == 'Error'),
                },
                hostname=hostname,
                ip_address=ip_address,
                version=version,
                uptime=uptime
            )
            
            self.stdout.write(
                self.style.SUCCESS(
                    f"Update status: {overall_status} "
                    f"({len(checks_results)} checks performed)"
                )
            )
            
        except Exception as exc:
            self.stderr.write(
                self.style.ERROR(f"Error during the saving in the DB: {exc}")
            )
            raise
    
    def _get_ip_address(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return None
