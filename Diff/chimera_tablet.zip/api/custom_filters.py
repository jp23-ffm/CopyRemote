from rest_framework.filters import BaseFilterBackend
from django.db.models import Q

class DynamicFilterBackend(BaseFilterBackend):
    def filter_queryset(self, request, queryset, view):
        filter_params = {}
        for key, value in request.query_params.items():
            if key.startswith('filter_'):
                field_name = key.split('filter_')[1]
                filter_params[field_name] = value

        if filter_params:
            query = Q()
            for field, value in filter_params.items():
                query &= Q(**{field: value})
            queryset = queryset.filter(query)

        return queryset
