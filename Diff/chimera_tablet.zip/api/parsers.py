from rest_framework.parsers import BaseParser
import orjson

class ORJSONParser(BaseParser):

    # Parser JSON based on orjson — quicker and no 1000 depth limit

    media_type = 'application/json'

    def parse(self, stream, media_type=None, parser_context=None):
        data = stream.read()
        if not data:
            return {}
        return orjson.loads(data)
