#!/usr/bin/env python3
"""
Generate fake inventory CSV data for testing.

Usage:
    python generate_fake_inventory.py
    python generate_fake_inventory.py --output /path/to/file.csv
    python generate_fake_inventory.py --count 10000

Requirements:
    pip install faker
"""

import argparse
import csv
import random
from pathlib import Path

try:
    from faker import Faker
except ImportError:
    print("ERROR: Faker is not installed. Run: pip install faker")
    exit(1)


# CSV column names (from field_mapping values in dbimport_inventory_csv.py)
CSV_COLUMNS = [
    "APM_ALL__APPSECPROFILE",
    "APM-DETAILS__APPLICATIONDESCRIPTION",
    "APM-DETAILS__APPLICATIONMANAGER",
    "APM-DETAILS__CRITICALITY",
    "APM-DETAILS__ITCLUSTER",
    "APM-DETAILS__ITCONTINUITYCRITICALITY",
    "APM-DETAILS__OWNERBUSINESSLINE",
    "APM-DETAILS__PRODUCTIONDOMAINMANAGER",
    "APM-DETAILS__PRODUCTIONMANAGER",
    "APM-DETAILS__VITALAPPLICATION",
    "APPLICATION_NAME_VALUE",
    "APPLICATION_AUID_VALUE",
    "BAMPLUS-APPLICATIONMANAGERS_EMAIL",
    "BAMPLUS-APPLICATIONS_EMAIL",
    "BAMPLUS-BUSINESSLINEOWNERS_EMAIL",
    "BAMPLUS-DEVELOPMENTMANAGERS_EMAIL",
    "BAMPLUS-INFRASTRUCTUREMANAGERS_EMAIL",
    "CAPSULE-REF-SERVERS__DPI",
    "CAPSULE-REF-SERVERS__ECOSYSTEM",
    "CAPSULE-REF-SERVERS__SUB_ID",
    "CAPSULE-REF-SERVERS__OWNER",
    "CAPSULE-REF-SERVERS__STATE",
    "K9-APPLICATIONS__ITAPPLICATIONSUPPORTGROUPS.K9-APPLICATIONS__EMAIL",
    "K9-APPLICATIONS__ITAPPLICATIONSUPPORTGROUPS.K9-APPLICATIONS__NAME",
    "OBSO_MAP__HW_ENDOFEXTENDEDDATE",
    "OPENSTACK__FLAVOR.OPENSTACK__LINKS.OPENSTACK__HREF",
    "OPENSTACK__KVM_HOST",
    "OPENSTACK__KVM_VM_STATE",
    "PAMELA__AFFINITY",
    "PAMELA__AREA",
    "PAMELA__ASSETGEN_CABINET",
    "PAMELA__ASSETGEN_ROOM",
    "PAMELA__CITY",
    "PAMELA__COUNTRY",
    "PAMELA_CPULOGICALTHREAD",
    "PAMELA__AD_DOMAIN",
    "PAMELA__DATACENTER",
    "PAMELA__DECOMREQ",
    "PAMELA__ENVIRONMENT",
    "PAMELA__FQDN",
    "PAMELA__HYPERVISOR",
    "PAMELA__IDRACIP",
    "PAMELA__IDRACNAME",
    "PAMELA__INFRAVERSION",
    "PAMELA__IPADDRESS",
    "PAMELA__LIVE_STATUS_FINAL",
    "PAMELA__MANUFACTURER",
    "PAMELA__MODEL",
    "PAMELA__NETIP",
    "PAMELA__NETMASK",
    "PAMELA__NETWORKID",
    "PAMELA__NETWORKNAME",
    "PAMELA__OBSO__HWPURCHASEDATE",
    "PAMELA__OG_INFRA",
    "PAMELA__OS",
    "PAMELA__OSFAMILY",
    "PAMELA__OSFULLVERSION",
    "PAMELA__OSSHORTNAME",
    "PAMELA__PAAS_COMMENT",
    "PAMELA__PAAS_PHASE",
    "PAMELA__PAAS_REQUESTER",
    "PAMELA__PARKPLACEENDON",
    "PAMELA__PARKPLACESTARTON",
    "PAMELA__PERIMETER",
    "PAMELA__PRODUCT",
    "PAMELA__PROVISIONNINGREQ",
    "PAMELA__SERIAL",
    "PAMELA__SHORT_ENVIRONMENT",
    "PAMELA__SNOWITG_STATUS",
    "PAMELA__SNOWITG_SUPPORTGROUP",
    "PAMELA__SUBPERIMETER",
    "PAMELA__SUBTECHFAMILY",
    "PAMELA__TECHFAMILY",
    "PAMELA__VMTYPE",
    "PAMELA__VPIC_CLUSTER",
    "SERVER_APPLICATION_VALUE",
    "SERVER_DATACENTER_VALUE",
    "SERVER_DISK_VALUE",
    "SERVER_ID",
    "SERVER_IP_VALUE",
    "SERVER_MACHINE_TYPE_VALUE",
    "SERVER_RAM_VALUE",
    "SNOW_SERVER__FLAG_ORPHAN",
    "VPIC__CLUSTER_NAME",
    "VPIC__DATACENTER",
    "VPIC__DATASTORE_NAME",
    "VPIC__HOST_NAME",
    "VPIC__OWNER_UID",
    "VPIC__POWERSTATE",
    "VPIC__RESOURCEPOOL",
    "VPIC__VCNAME",
    "VPIC__VMGROUPS",
]

# ============================================================================
# REALISTIC DATA POOLS
# ============================================================================

DATACENTERS = [
    "DC-PARIS-01", "DC-PARIS-02", "DC-LONDON-01", "DC-FRANKFURT-01",
    "DC-AMSTERDAM-01", "DC-SINGAPORE-01", "DC-NEWYORK-01", "DC-DUBLIN-01",
]

REGIONS = ["EMEA", "APAC", "AMER", "EURO"]

ENVIRONMENTS = ["PROD", "UAT", "DEV", "STG", "QA", "PREPROD"]
SHORT_ENVIRONMENTS = ["P", "U", "D", "S", "Q", "PP"]

COUNTRIES = ["FR", "UK", "DE", "NL", "SG", "US", "IE", "BE", "CH", "IT"]

CITIES = {
    "FR": ["Paris", "Lyon", "Marseille"],
    "UK": ["London", "Manchester", "Edinburgh"],
    "DE": ["Frankfurt", "Berlin", "Munich"],
    "NL": ["Amsterdam", "Rotterdam"],
    "SG": ["Singapore"],
    "US": ["New York", "Chicago", "Los Angeles"],
    "IE": ["Dublin"],
    "BE": ["Brussels"],
    "CH": ["Zurich", "Geneva"],
    "IT": ["Milan", "Rome"],
}

OS_FAMILIES = ["Linux", "Windows", "AIX", "Solaris"]
OS_NAMES = {
    "Linux": ["RHEL 7.9", "RHEL 8.6", "RHEL 9.0", "Ubuntu 20.04", "Ubuntu 22.04", "SLES 15"],
    "Windows": ["Windows Server 2019", "Windows Server 2022", "Windows Server 2016"],
    "AIX": ["AIX 7.2", "AIX 7.3"],
    "Solaris": ["Solaris 11.4"],
}

TECH_FAMILIES = ["Compute", "Database", "Middleware", "Storage", "Network", "Security"]
SUBTECH_FAMILIES = {
    "Compute": ["Virtual Machine", "Physical Server", "Container"],
    "Database": ["Oracle", "SQL Server", "PostgreSQL", "MySQL", "MongoDB"],
    "Middleware": ["WebSphere", "Tomcat", "JBoss", "WebLogic", "IIS"],
    "Storage": ["SAN", "NAS", "Object Storage"],
    "Network": ["Load Balancer", "Firewall", "Router"],
    "Security": ["HSM", "Vault", "PKI"],
}

MANUFACTURERS = ["Dell", "HP", "Lenovo", "IBM", "Cisco", "VMware"]

MODELS = {
    "Dell": ["PowerEdge R740", "PowerEdge R750", "PowerEdge R640"],
    "HP": ["ProLiant DL380", "ProLiant DL360", "ProLiant DL580"],
    "Lenovo": ["ThinkSystem SR650", "ThinkSystem SR630"],
    "IBM": ["Power S922", "Power E980"],
    "Cisco": ["UCS C220", "UCS C240"],
    "VMware": ["Virtual Machine", "vSphere VM"],
}

VM_TYPES = ["VM", "Physical", "Container", "LPar"]
LIVE_STATUSES = ["Live", "Decommissioned", "Provisioning", "Maintenance", "Parked"]
CRITICALITIES = ["Critical", "High", "Medium", "Low"]

BUSINESS_LINES = [
    "Corporate Banking", "Retail Banking", "Investment Banking",
    "Asset Management", "Insurance", "IT Operations", "HR", "Finance",
]

IT_CLUSTERS = [
    "CLUSTER-BANKING-CORE", "CLUSTER-TRADING", "CLUSTER-RISK",
    "CLUSTER-PAYMENTS", "CLUSTER-DATA", "CLUSTER-WEB", "CLUSTER-MOBILE",
    "CLUSTER-INFRA", "CLUSTER-SECURITY", "CLUSTER-ANALYTICS",
]

APPLICATIONS = [
    "CoreBanking", "TradingPlatform", "RiskEngine", "PaymentGateway",
    "DataWarehouse", "CustomerPortal", "MobileApp", "EmailServer",
    "ActiveDirectory", "MonitoringSystem", "BackupServer", "DNSServer",
    "LoadBalancer", "Firewall", "WebServer", "AppServer", "DBServer",
    "FileServer", "PrintServer", "ProxyServer", "CacheServer",
]

SUPPORT_GROUPS = [
    "SUPPORT-UNIX-L2", "SUPPORT-WINDOWS-L2", "SUPPORT-DBA-ORACLE",
    "SUPPORT-DBA-SQLSERVER", "SUPPORT-MIDDLEWARE", "SUPPORT-NETWORK",
    "SUPPORT-STORAGE", "SUPPORT-SECURITY", "SUPPORT-CLOUD",
]

HYPERVISORS = ["VMware vSphere", "Hyper-V", "KVM", "PowerVM", "None"]
SNOW_STATUSES = ["Operational", "Retired", "Under maintenance", "Planned"]
PERIMETERS = ["Internal", "DMZ", "External", "Restricted"]
PRODUCTS = ["Standard VM", "Premium VM", "Bare Metal", "Container Platform"]


# ============================================================================
# GENERATOR FUNCTIONS
# ============================================================================

def generate_server_id(fake, existing_ids):
    """Generate a unique server ID."""
    prefixes = ["SRV", "VM", "PRD", "APP", "DB", "WEB", "LNX", "WIN"]
    while True:
        prefix = random.choice(prefixes)
        number = random.randint(10000, 99999)
        suffix = random.choice(["", "A", "B", "P", "D"])
        server_id = f"{prefix}{number}{suffix}"
        if server_id not in existing_ids:
            existing_ids.add(server_id)
            return server_id


def generate_server_row(fake, server_id):
    """Generate a complete server row."""
    # Pick consistent values for related fields
    country = random.choice(COUNTRIES)
    city = random.choice(CITIES.get(country, ["Unknown"]))
    region = random.choice(REGIONS)
    datacenter = random.choice(DATACENTERS)
    env = random.choice(ENVIRONMENTS)
    short_env = SHORT_ENVIRONMENTS[ENVIRONMENTS.index(env)]

    os_family = random.choice(OS_FAMILIES)
    os_name = random.choice(OS_NAMES[os_family])
    os_short = os_name.split()[0]

    manufacturer = random.choice(MANUFACTURERS)
    model = random.choice(MODELS[manufacturer])

    tech_family = random.choice(TECH_FAMILIES)
    subtech_family = random.choice(SUBTECH_FAMILIES[tech_family])

    app_name = random.choice(APPLICATIONS)
    business_line = random.choice(BUSINESS_LINES)
    it_cluster = random.choice(IT_CLUSTERS)
    criticality = random.choice(CRITICALITIES)

    ip_base = f"10.{random.randint(1,254)}.{random.randint(1,254)}"
    ip = f"{ip_base}.{random.randint(1,254)}"

    manager_name = fake.name()
    manager_email = fake.company_email()

    # Generate timestamps (milliseconds since epoch)
    purchase_date = int(fake.date_time_between(
        start_date='-5y', end_date='-1y'
    ).timestamp() * 1000)
    end_date = int(fake.date_time_between(
        start_date='+1y', end_date='+5y'
    ).timestamp() * 1000)

    return {
        "APM_ALL__APPSECPROFILE": random.choice(["Standard", "Enhanced", "Restricted"]),
        "APM-DETAILS__APPLICATIONDESCRIPTION": f"{app_name} application for {business_line}",
        "APM-DETAILS__APPLICATIONMANAGER": manager_name,
        "APM-DETAILS__CRITICALITY": criticality,
        "APM-DETAILS__ITCLUSTER": it_cluster,
        "APM-DETAILS__ITCONTINUITYCRITICALITY": criticality,
        "APM-DETAILS__OWNERBUSINESSLINE": business_line,
        "APM-DETAILS__PRODUCTIONDOMAINMANAGER": fake.name(),
        "APM-DETAILS__PRODUCTIONMANAGER": fake.name(),
        "APM-DETAILS__VITALAPPLICATION": random.choice(["Yes", "No"]),
        "APPLICATION_NAME_VALUE": app_name,
        "APPLICATION_AUID_VALUE": f"AUID{random.randint(10000, 99999)}",
        "BAMPLUS-APPLICATIONMANAGERS_EMAIL": manager_email,
        "BAMPLUS-APPLICATIONS_EMAIL": f"{app_name.lower()}@company.com",
        "BAMPLUS-BUSINESSLINEOWNERS_EMAIL": fake.company_email(),
        "BAMPLUS-DEVELOPMENTMANAGERS_EMAIL": fake.company_email(),
        "BAMPLUS-INFRASTRUCTUREMANAGERS_EMAIL": fake.company_email(),
        "CAPSULE-REF-SERVERS__DPI": f"DPI-{random.randint(1000, 9999)}",
        "CAPSULE-REF-SERVERS__ECOSYSTEM": random.choice(["Production", "Non-Production"]),
        "CAPSULE-REF-SERVERS__SUB_ID": f"SUB-{random.randint(100000, 999999)}",
        "CAPSULE-REF-SERVERS__OWNER": fake.user_name(),
        "CAPSULE-REF-SERVERS__STATE": random.choice(["Active", "Inactive", "Pending"]),
        "K9-APPLICATIONS__ITAPPLICATIONSUPPORTGROUPS.K9-APPLICATIONS__EMAIL": f"{random.choice(SUPPORT_GROUPS).lower()}@company.com",
        "K9-APPLICATIONS__ITAPPLICATIONSUPPORTGROUPS.K9-APPLICATIONS__NAME": random.choice(SUPPORT_GROUPS),
        "OBSO_MAP__HW_ENDOFEXTENDEDDATE": str(end_date),
        "OPENSTACK__FLAVOR.OPENSTACK__LINKS.OPENSTACK__HREF": f"https://openstack.company.com/flavors/{random.randint(1,100)}",
        "OPENSTACK__KVM_HOST": f"kvm-host-{random.randint(1, 50)}.company.com",
        "OPENSTACK__KVM_VM_STATE": random.choice(["ACTIVE", "SHUTOFF", "PAUSED"]),
        "PAMELA__AFFINITY": random.choice(["Affinity-Group-A", "Affinity-Group-B", "None"]),
        "PAMELA__AREA": region,
        "PAMELA__ASSETGEN_CABINET": f"CAB-{random.randint(1, 100):03d}",
        "PAMELA__ASSETGEN_ROOM": f"ROOM-{random.choice(['A', 'B', 'C', 'D'])}{random.randint(1, 10)}",
        "PAMELA__CITY": city,
        "PAMELA__COUNTRY": country,
        "PAMELA_CPULOGICALTHREAD": str(random.choice([2, 4, 8, 16, 32, 64])),
        "PAMELA__AD_DOMAIN": f"{region.lower()}.company.net",
        "PAMELA__DATACENTER": datacenter,
        "PAMELA__DECOMREQ": "",
        "PAMELA__ENVIRONMENT": env,
        "PAMELA__FQDN": f"{server_id.lower()}.{region.lower()}.company.net",
        "PAMELA__HYPERVISOR": random.choice(HYPERVISORS),
        "PAMELA__IDRACIP": f"{ip_base}.{random.randint(200, 254)}",
        "PAMELA__IDRACNAME": f"{server_id.lower()}-idrac",
        "PAMELA__INFRAVERSION": f"v{random.randint(1, 5)}.{random.randint(0, 9)}",
        "PAMELA__IPADDRESS": ip,
        "PAMELA__LIVE_STATUS_FINAL": random.choice(LIVE_STATUSES),
        "PAMELA__MANUFACTURER": manufacturer,
        "PAMELA__MODEL": model,
        "PAMELA__NETIP": f"{ip_base}.0/24",
        "PAMELA__NETMASK": "255.255.255.0",
        "PAMELA__NETWORKID": f"NET-{random.randint(1000, 9999)}",
        "PAMELA__NETWORKNAME": f"VLAN-{random.choice(['PROD', 'DMZ', 'MGMT', 'BACKUP'])}-{random.randint(100, 999)}",
        "PAMELA__OBSO__HWPURCHASEDATE": str(purchase_date),
        "PAMELA__OG_INFRA": random.choice(["OpenStack", "VMware", "Bare Metal", "Azure"]),
        "PAMELA__OS": os_name,
        "PAMELA__OSFAMILY": os_family,
        "PAMELA__OSFULLVERSION": os_name,
        "PAMELA__OSSHORTNAME": os_short,
        "PAMELA__PAAS_COMMENT": "",
        "PAMELA__PAAS_PHASE": random.choice(["", "Phase1", "Phase2", "Completed"]),
        "PAMELA__PAAS_REQUESTER": "",
        "PAMELA__PARKPLACEENDON": "",
        "PAMELA__PARKPLACESTARTON": "",
        "PAMELA__PERIMETER": random.choice(PERIMETERS),
        "PAMELA__PRODUCT": random.choice(PRODUCTS),
        "PAMELA__PROVISIONNINGREQ": f"REQ{random.randint(100000, 999999)}",
        "PAMELA__SERIAL": fake.uuid4()[:12].upper(),
        "PAMELA__SHORT_ENVIRONMENT": short_env,
        "PAMELA__SNOWITG_STATUS": random.choice(SNOW_STATUSES),
        "PAMELA__SNOWITG_SUPPORTGROUP": random.choice(SUPPORT_GROUPS),
        "PAMELA__SUBPERIMETER": random.choice(["SubA", "SubB", "SubC"]),
        "PAMELA__SUBTECHFAMILY": subtech_family,
        "PAMELA__TECHFAMILY": tech_family,
        "PAMELA__VMTYPE": random.choice(VM_TYPES),
        "PAMELA__VPIC_CLUSTER": f"VPIC-{datacenter}-{random.randint(1, 10):02d}",
        "SERVER_APPLICATION_VALUE": app_name,
        "SERVER_DATACENTER_VALUE": datacenter,
        "SERVER_DISK_VALUE": str(random.choice([100, 200, 500, 1000, 2000])),
        "SERVER_ID": server_id,
        "SERVER_IP_VALUE": ip,
        "SERVER_MACHINE_TYPE_VALUE": random.choice(VM_TYPES),
        "SERVER_RAM_VALUE": str(random.choice([4, 8, 16, 32, 64, 128, 256])),
        "SNOW_SERVER__FLAG_ORPHAN": random.choice(["No", "No", "No", "Yes"]),
        "VPIC__CLUSTER_NAME": f"VPIC-CLUSTER-{random.randint(1, 20):02d}",
        "VPIC__DATACENTER": datacenter,
        "VPIC__DATASTORE_NAME": f"DS-{datacenter}-{random.randint(1, 50):03d}",
        "VPIC__HOST_NAME": f"esxi-{random.randint(1, 100):03d}.company.com",
        "VPIC__OWNER_UID": fake.user_name(),
        "VPIC__POWERSTATE": random.choice(["poweredOn", "poweredOff", "suspended"]),
        "VPIC__RESOURCEPOOL": f"RP-{env}-{random.randint(1, 10):02d}",
        "VPIC__VCNAME": f"vcenter-{region.lower()}-{random.randint(1, 5):02d}",
        "VPIC__VMGROUPS": f"VMG-{app_name[:3].upper()}-{random.randint(1, 10):02d}",
    }


# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description='Generate fake inventory CSV data for testing'
    )
    parser.add_argument(
        '--output', '-o',
        type=str,
        default='dpr_pamela_inventory_prod.csv',
        help='Output CSV file path (default: dpr_pamela_inventory_prod.csv)'
    )
    parser.add_argument(
        '--count', '-c',
        type=int,
        default=5000,
        help='Number of unique servers to generate (default: 5000)'
    )
    parser.add_argument(
        '--seed', '-s',
        type=int,
        default=42,
        help='Random seed for reproducibility (default: 42)'
    )

    args = parser.parse_args()

    # Initialize
    random.seed(args.seed)
    fake = Faker()
    Faker.seed(args.seed)

    print(f"Generating {args.count} servers...")

    rows = []
    server_ids_generated = set()

    # 90% single entry, 10% multiple entries (2-4)
    single_entry_count = int(args.count * 0.90)
    multi_entry_count = args.count - single_entry_count

    # Generate single-entry servers
    for i in range(single_entry_count):
        server_id = generate_server_id(fake, server_ids_generated)
        row = generate_server_row(fake, server_id)
        rows.append(row)

        if (i + 1) % 1000 == 0:
            print(f"  Generated {i + 1} single-entry servers...")

    # Generate multi-entry servers (2-4 entries each)
    for i in range(multi_entry_count):
        server_id = generate_server_id(fake, server_ids_generated)
        num_entries = random.choice([2, 2, 2, 3, 3, 4])  # Weighted towards 2-3

        base_row = generate_server_row(fake, server_id)

        for j in range(num_entries):
            row = base_row.copy()
            if j > 0:
                # Vary APPLICATION_NAME_VALUE and ITCLUSTER
                row["APPLICATION_NAME_VALUE"] = random.choice(APPLICATIONS) + f"_{j+1}"
                row["APM-DETAILS__ITCLUSTER"] = random.choice(IT_CLUSTERS)
                row["APPLICATION_AUID_VALUE"] = f"AUID{random.randint(10000, 99999)}"
            rows.append(row)

    # Add ~5% entries with missing critical fields
    missing_count = int(len(rows) * 0.05)
    missing_indices = random.sample(range(len(rows)), missing_count)
    missing_fields = [
        "APM-DETAILS__ITCLUSTER",
        "PAMELA__DATACENTER",
        "APPLICATION_NAME_VALUE",
        "PAMELA__ENVIRONMENT",
    ]

    for idx in missing_indices:
        field_to_empty = random.choice(missing_fields)
        rows[idx][field_to_empty] = ""

    # Shuffle rows
    random.shuffle(rows)

    # Write CSV
    print(f"Writing {len(rows)} rows to {args.output}...")

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)

    with open(args.output, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(
            f,
            fieldnames=CSV_COLUMNS,
            delimiter=';',
            quotechar='"',
            quoting=csv.QUOTE_ALL
        )
        writer.writeheader()
        writer.writerows(rows)

    # Stats
    unique_servers = len(set(row["SERVER_ID"] for row in rows))
    empty_datacenter = sum(1 for r in rows if not r["PAMELA__DATACENTER"])
    empty_itcluster = sum(1 for r in rows if not r["APM-DETAILS__ITCLUSTER"])
    empty_app = sum(1 for r in rows if not r["APPLICATION_NAME_VALUE"])
    empty_env = sum(1 for r in rows if not r["PAMELA__ENVIRONMENT"])

    print(f"\nDone!")
    print(f"Output: {args.output}")
    print(f"\nStatistics:")
    print(f"  Unique SERVER_IDs: {unique_servers}")
    print(f"  Total entries: {len(rows)}")
    print(f"  Multi-entry servers: {multi_entry_count} (~{multi_entry_count/args.count*100:.0f}%)")
    print(f"\nEmpty fields:")
    print(f"  PAMELA__DATACENTER: {empty_datacenter}")
    print(f"  APM-DETAILS__ITCLUSTER: {empty_itcluster}")
    print(f"  APPLICATION_NAME_VALUE: {empty_app}")
    print(f"  PAMELA__ENVIRONMENT: {empty_env}")


if __name__ == '__main__':
    main()
