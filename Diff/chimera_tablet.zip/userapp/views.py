from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from .models import CustomUser, UserProfile
from .forms import CustomUserCreationForm, CustomUserChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages

def root_redirect(request):
    return redirect('/login/')


def register_view(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            UserProfile.objects.create(user=user)
            login(request, user)
            return redirect('reportapp:server_view')  # Redirect to the reportapp page after registration
    else:
        form = CustomUserCreationForm()
    return render(request, 'userapp/register.html', {'form': form})


def initiate_sso(request):
    # Clear the current session
    request.session.flush()
    # Get the application selection from the GET parameters (e.g., ?app=continuity)
    app_selection = request.GET.get('app', 'reportapp')  # Valor por defecto 'reportapp'
    # Set the destination based on the selection
    if app_selection == 'continuity':
        next_url = "/continuity/servers/"
    elif app_selection == 'reportapp':
        next_url = "/reportapp/servers/"
    else:
        next_url = "/businescontinuity/"
    # Redirect to the SSO endpoint with the 'next' parameter
    return redirect(f"/saml2/login/?next={next_url}")




def custom_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        app_selection = request.POST.get('app_selection', 'reportapp')  # Default to reportapp if no app is selected

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)

            # Redirect to the selected app
            if app_selection == 'continuity':
                return redirect('continuity:server_view')
            elif app_selection == 'reportapp':
                return redirect('reportapp:server_view')
            elif app_selection == 'businesscontinuity':
                return redirect('businesscontinuity:servers_list')
            else:
                messages.error(request, "Invalid application selection.")
                return redirect('login')

        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')

    return render(request, 'userapp/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def profile_view(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    return render(request, 'userapp/profile.html', {'profile': profile})

