# export PYTHONPATH=/apps/chimera:$PYTHONPATH


import os
import django
import duckdb
import pandas as pd
import datetime
#os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'chimera.settings') 
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'chimeradev.settings') 
django.setup()

from businesscontinuity.models import ServerUnique
print("Cleaning")
ServerUnique.objects.update(priority_asset="EMPTY", in_live_play="EMPTY", action_during_lp="EMPTY", action_during_lp_history=None, original_action_during_lp="EMPTY", original_action_during_lp_history=None, cluster="EMPTY", cluster_type="EMPTY")
