from django.core.management.base import BaseCommand
from businesscontinuity.management.commands.export_businesscontinuity import export_businesscontinuity

class Command(BaseCommand):
    help = "Export the server data to XLSX, CSV, or JSON."

    def add_arguments(self, parser):
        parser.add_argument('export_format', type=str, choices=['xlsx', 'csv', 'json'], help='The format to export the data.')

    def handle(self, *args, **options):
        export_format = options['export_format']
        success, message = export_businesscontinuity(export_format)
        if success:
            self.stdout.write(self.style.SUCCESS(message))
        else:
            self.stderr.write(self.style.ERROR(message))

