from django import forms
from .models import ServerAnnotation

class AnnotationForm(forms.ModelForm):
    type = forms.CharField(
        required=False,
        widget=forms.Select(choices=[
            ('', 'Select type'),
            ('ERROR', 'ERROR'),
            ('INFO', 'INFO'),
            ('WARNING', 'WARNING'),
            ('CUSTOM', 'Custom Type')
        ], attrs={
            'class': 'annotation-type',
            'id': 'annotation-type'
        })
    )
    custom_type = forms.CharField(
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Enter custom type...',
            'class': 'annotation-custom-type',
            'id': 'custom-type'
        })
    )

    class Meta:
        model = ServerAnnotation
        fields = ['notes', 'servicenow']
        widgets = {
            'notes': forms.Textarea(attrs={
                'rows': 4,
                'placeholder': 'Add annotation for this server...',
                'class': 'annotation-textarea',
                'id': 'annotation-notes'
            }),
            'servicenow': forms.TextInput(attrs={
                'placeholder': 'Enter ServiceNow RITM number...',
                'class': 'annotation-servicenow',
                'id': 'annotation-servicenow'
            })
        }
        labels = {
            'notes': 'Annotation',
            'servicenow': 'ServiceNow RITM'
        }

    def clean(self):
        cleaned_data = super().clean()
        annotation_type = cleaned_data.get('type')
        custom_type = cleaned_data.get('custom_type')

        if annotation_type == 'CUSTOM' and not custom_type:
            self.add_error('custom_type', 'Custom type is required when "Custom Type" is selected.')

        if annotation_type != 'CUSTOM' and custom_type:
            self.add_error('custom_type', 'Custom type is not allowed when a predefined type is selected.')

        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.type = self.cleaned_data.get('type')
        if instance.type == 'CUSTOM':
            instance.type = self.cleaned_data.get('custom_type')
        if commit:
            instance.save()
        return instance
        
        
# Form for CSV file upload
class CsvUploadForm(forms.Form):
    csv_file = forms.FileField(label="Select a CSV file")
    
