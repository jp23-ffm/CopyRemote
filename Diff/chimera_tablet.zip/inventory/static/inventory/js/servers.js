document.addEventListener('DOMContentLoaded', function () {  // Wait for the DOM to be fully loaded before executing the script

    // Get needed references

    var serversTable = document.getElementById('serversTable');
    var userCanEdit = serversTable.dataset.userCanedit === 'True';


    if (userCanEdit) { 
    
        document.getElementById('bulkEditModal').querySelector('.close-button').addEventListener('click', closeBulkModal);  // Event listener to the close button in the bulk edit modal
        
        document.getElementById('bulkEditButton').addEventListener('click', function () {  // Event listener to the bulk edit button
            document.getElementById('bulkEditModal').style.display = 'flex';
console.log("bulk");
        });
    
    }

    
    document.getElementById('bulkEditModal').addEventListener('click', function (event) {  // Event listener to the bulk edit modal: If the user clicks on the modal background, close the modal
        if (event.target === this) {
            closeBulkModal();
        }
    });

    
    document.getElementById('bulkEditModal').querySelector('.btn-secondary').addEventListener('click', closeBulkModal);  // Event listener to the secondary button in the bulk edit modal


    document.addEventListener('keydown', function (e) {  // Event listener for the Escape key
        if (e.key === 'Escape') {
            closeBulkModal();
        }
    });


});


