let contextMenuServer = null;
let currentServerData = null;

document.addEventListener('DOMContentLoaded', function() {
    const contextMenu = document.getElementById('contextMenu');
    
    // Right click
    document.addEventListener('contextmenu', function(e) {
        const row = e.target.closest('tr[data-server-id]');
        
        if (row) {
            e.preventDefault();
            contextMenuServer = JSON.parse(row.dataset.serverData);
            
            contextMenu.style.display = 'block';
            contextMenu.style.left = e.pageX + 'px';
            contextMenu.style.top = e.pageY + 'px';
        }
    });
    
    document.addEventListener('click', function() {
        contextMenu.style.display = 'none';
    });
    
    contextMenu.addEventListener('click', function(e) {
        e.stopPropagation();
    });
});

function showServerDetails() {
    if (!contextMenuServer) return;
    
    currentServerData = contextMenuServer;
    
    document.getElementById('serverDetailsTitle').textContent = 
        `Server Details: ${currentServerData.hostname || currentServerData.SERVER_ID}`;
    
    // Use json_data for the content
    const content = document.getElementById('serverDetailsContent');
    content.innerHTML = '';
    
    // Organise by categories from json_data
    const fieldsByCategory = {};
    
    // Process all json_data fields
    for (const [fieldKey, fieldInfo] of Object.entries(jsonData.fields || {})) {
        const category = fieldInfo.selectionsection; // ex: "cat1", "cat2"
        const categoryName = jsonData[category]; // ex: "Application", "Hardware"
        const displayName = fieldInfo.displayname;
        const inputName = fieldInfo.inputname;
        
        // Get the server value
        const value = currentServerData[inputName];
        
        // Skip if no value
        if (value === null || value === undefined || value === '') continue;
        
        // Group by category
        if (!fieldsByCategory[categoryName]) {
            fieldsByCategory[categoryName] = [];
        }
        
        fieldsByCategory[categoryName].push({
            displayName: displayName,
            inputName: inputName,
            value: value
        });
    }
    
    // Create the sections
    for (const [categoryName, fields] of Object.entries(fieldsByCategory)) {
        if (fields.length === 0) continue;
        
        const section = document.createElement('div');
        section.className = 'detail-section';
        
        const header = document.createElement('h6');
        header.textContent = categoryName;
        section.appendChild(header);
        
        // Add the fields
        fields.forEach(field => {
            const fieldDiv = document.createElement('div');
            fieldDiv.className = 'detail-field';
            fieldDiv.setAttribute('data-field', field.inputName);
            
            const label = document.createElement('div');
            label.className = 'detail-label';
            label.textContent = field.displayName;
            
            const valueDiv = document.createElement('div');
            valueDiv.className = 'detail-value';
            
            // Escape values if needed
            const escapedValue = String(field.value).replace(/'/g, "\\'");
            
            valueDiv.innerHTML = `
                <span>${field.value}</span>
                <span class="copy-icon" onclick="copyToClipboard('${escapedValue}')">📋</span>
            `;
            
            fieldDiv.appendChild(label);
            fieldDiv.appendChild(valueDiv);
            section.appendChild(fieldDiv);
        });
        
        content.appendChild(section);
    }
    
    // Display the modal
    document.getElementById('serverDetailsModal').style.display = 'flex';
    document.getElementById('contextMenu').style.display = 'none';
}

function closeServerDetails() {
    document.getElementById('serverDetailsModal').style.display = 'none';
}


function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {

        const toast = document.createElement('div');
        toast.textContent = '✓ Copied!';
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success-color, #28a745);
            color: white;
            padding: 12px 20px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10001;
            animation: slideIn 0.3s ease;
        `;
        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2000);
    });
}


// Animation CSS for the toast
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeServerDetails();
    }
});
