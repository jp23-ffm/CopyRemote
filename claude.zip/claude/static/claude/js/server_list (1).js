// static/myapp/js/server_list.js
const ServerState = {
    STORAGE_KEY: 'server_expanded_state',
    
    // Debug: afficher dans la console
    debugLog(message, data) {
        console.log('[ServerState]', message, data || '');
    },
    
    getExpandedServers() {
        try {
            const stored = sessionStorage.getItem(this.STORAGE_KEY);
            const result = stored ? JSON.parse(stored) : [];
            this.debugLog('Récupération état:', result);
            return result;
        } catch (e) {
            this.debugLog('Erreur récupération:', e.message);
            return [];
        }
    },
    
    saveExpandedServers(expandedList) {
        try {
            sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(expandedList));
            this.debugLog('Sauvegarde état:', expandedList);
            
            // Vérification immédiate
            const verification = sessionStorage.getItem(this.STORAGE_KEY);
            this.debugLog('Vérification sauvegarde:', verification);
        } catch (e) {
            this.debugLog('Erreur sauvegarde:', e.message);
            // Fallback: stocker dans une variable globale
            window.expandedServersBackup = expandedList;
        }
    },
    
    addToExpanded(hostname) {
        const expanded = this.getExpandedServers();
        if (!expanded.includes(hostname)) {
            expanded.push(hostname);
            this.saveExpandedServers(expanded);
            this.debugLog('Ajouté:', hostname);
        }
    },
    
    removeFromExpanded(hostname) {
        const expanded = this.getExpandedServers();
        const index = expanded.indexOf(hostname);
        if (index > -1) {
            expanded.splice(index, 1);
            this.saveExpandedServers(expanded);
            this.debugLog('Supprimé:', hostname);
        }
    },
    
    // Fonction pour normaliser les hostnames (même logique que slugify Django)
    normalizeHostname(hostname) {
        return hostname.toLowerCase()
                      .replace(/[^a-z0-9]/g, '-')
                      .replace(/-+/g, '-')
                      .replace(/^-|-$/g, '');
    },
    
    toggleDetails(hostnameSlug) {
        this.debugLog('Toggle appelé avec:', hostnameSlug);
        
        const primaryRow = document.getElementById('primary-' + hostnameSlug);
        const detailRows = document.querySelectorAll('[id^="detail-' + hostnameSlug + '-"]');
        
        this.debugLog('Éléments trouvés:', {
            primary: !!primaryRow,
            details: detailRows.length
        });
        
        if (!primaryRow || detailRows.length === 0) {
            this.debugLog('Erreur: éléments non trouvés');
            return;
        }
        
        const isExpanded = primaryRow.style.display === 'none';
        
        if (isExpanded) {
            // Replier
            primaryRow.style.display = 'table-row';
            detailRows.forEach(row => row.style.display = 'none');
            this.removeFromExpanded(hostnameSlug);
            this.debugLog('Replié:', hostnameSlug);
        } else {
            // Déplier
            primaryRow.style.display = 'none';
            detailRows.forEach(row => row.style.display = 'table-row');
            this.addToExpanded(hostnameSlug);
            this.debugLog('Déplié:', hostnameSlug);
        }
    },
    
    restoreExpandedState() {
        this.debugLog('Restauration de l\'état...');
        
        // Essayer sessionStorage puis fallback
        let expandedServers = this.getExpandedServers();
        if (expandedServers.length === 0 && window.expandedServersBackup) {
            expandedServers = window.expandedServersBackup;
            this.debugLog('Utilisation fallback:', expandedServers);
        }
        
        // Lister tous les hostnames disponibles sur cette page
        const availableRows = document.querySelectorAll('.primary-row');
        this.debugLog('Lignes disponibles:', Array.from(availableRows).map(row => row.id));
        
        expandedServers.forEach(hostnameSlug => {
            const primaryRow = document.getElementById('primary-' + hostnameSlug);
            const detailRows = document.querySelectorAll('[id^="detail-' + hostnameSlug + '-"]');
            
            this.debugLog('Tentative restauration:', hostnameSlug, {
                primary: !!primaryRow,
                details: detailRows.length
            });
            
            if (primaryRow && detailRows.length > 0) {
                // Appliquer l'état étendu
                primaryRow.style.display = 'none';
                detailRows.forEach(row => row.style.display = 'table-row');
                this.debugLog('Restauré:', hostnameSlug);
            }
        });
    },
    
    // Nettoyer le sessionStorage des hostnames qui ne sont plus sur cette page
    cleanupStorage() {
        const expandedServers = this.getExpandedServers();
        const currentPageHostnames = Array.from(document.querySelectorAll('.primary-row')).map(row => 
            row.id.replace('primary-', '')
        );
        
        // Garder seulement les hostnames qui existent sur cette page
        const validExpanded = expandedServers.filter(hostname => 
            currentPageHostnames.includes(hostname)
        );
        
        if (validExpanded.length !== expandedServers.length) {
            this.saveExpandedServers(validExpanded);
        }
    },
    
    init() {
        // Test de sessionStorage au démarrage
        this.debugLog('Initialisation...');
        this.debugLog('SessionStorage disponible:', typeof(Storage) !== "undefined");
        
        // Restaurer l'état des serveurs étendus
        this.restoreExpandedState();
        
        // Ajouter les event listeners pour le double-clic
        document.querySelectorAll('.server-row').forEach(row => {
            row.addEventListener('dblclick', () => {
                const hostname = row.dataset.hostname;
                const slugified = hostname.toLowerCase().replace(/\./g, '-');
                const expandBtn = document.querySelector('#primary-' + slugified + ' .expand-btn, #detail-' + slugified + '-1 .expand-btn');
                if (expandBtn) {
                    this.toggleDetails(slugified);
                }
            });
        });
        
        // Nettoyer au chargement de la page
        setTimeout(() => this.cleanupStorage(), 100);
    }
};

// Fonction globale pour les onclick dans le HTML
function toggleDetails(hostnameSlug) {
    ServerState.toggleDetails(hostnameSlug);
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    ServerState.init();
});

// Fermer tous les détails avec Escape
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        // Replier tous les serveurs étendus
        document.querySelectorAll('.primary-row[style*="none"]').forEach(primaryRow => {
            const hostname = primaryRow.id.replace('primary-', '');
            const detailRows = document.querySelectorAll('[id^="detail-' + hostname + '-"]');
            
            primaryRow.style.display = 'table-row';
            detailRows.forEach(row => row.style.display = 'none');
            ServerState.removeFromExpanded(hostname);
        });
    }
});