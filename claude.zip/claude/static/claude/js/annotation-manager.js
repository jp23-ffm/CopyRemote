// static/myapp/js/annotation-manager.js

let currentHostname = null;

function editAnnotation(hostname) {
    currentHostname = hostname;
    console.log('[Annotation] Édition de:', hostname);
    
    // Afficher le modal d'abord
    document.getElementById('annotationModal').style.display = 'flex';

    // Puis remplir le hostname
    document.getElementById('modal-hostname').value = hostname;
    
    // Charger les données existantes
    fetch(`/annotation/${encodeURIComponent(hostname)}/`)
        .then(response => response.json())
        .then(data => {
            // Remplir le reste du formulaire
            document.getElementById('status').value = data.status;
            document.getElementById('custom_status').value = data.custom_status;
            document.getElementById('notes').value = data.notes;
            document.getElementById('priority').value = data.priority;
            
            // Afficher/masquer le champ statut personnalisé
            //toggleCustomStatus();
        })
        .catch(error => {
            console.error('[Annotation] Erreur lors du chargement:', error);
            alert('Erreur lors du chargement de l\'annotation');
        });
}

function toggleCustomStatus() {
    const statusSelect = document.getElementById('status');
    const customGroup = document.getElementById('customStatusGroup');
    const customInput = document.getElementById('custom_status');
    
    if (statusSelect.value === 'custom') {
        customGroup.style.display = 'block';
        customInput.required = true;
    } else {
        customGroup.style.display = 'none';
        customInput.required = false;
        customInput.value = '';
    }
}

function closeAnnotationModal() {
    document.getElementById('annotationModal').style.display = 'none';
    currentHostname = null;
    
    // Réinitialiser le formulaire
    document.getElementById('annotationForm').reset();
    toggleCustomStatus();
}

function saveAnnotation() {
    if (!currentHostname) {
        alert('Erreur: aucun serveur sélectionné');
        return;
    }
    
    // Validation
    const status = document.getElementById('status').value;
    const customStatus = document.getElementById('custom_status').value;
    
    if (status === 'custom' && !customStatus.trim()) {
        alert('Veuillez entrer un statut personnalisé');
        document.getElementById('custom_status').focus();
        return;
    }
    
    // Préparer les données
    const formData = {
        status: status,
        custom_status: customStatus,
        notes: document.getElementById('notes').value,
        priority: document.getElementById('priority').value
    };
    
    console.log('[Annotation] Sauvegarde:', currentHostname, formData);
    
    // Désactiver le bouton pendant la sauvegarde
    const saveBtn = document.querySelector('.btn-save');
    const originalText = saveBtn.textContent;
    saveBtn.disabled = true;
    saveBtn.textContent = 'Sauvegarde...';
    
    // Envoyer les données
    fetch(`/annotation/${encodeURIComponent(currentHostname)}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCsrfToken()
        },
        body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log('[Annotation] Sauvegardé avec succès');
            
            // Fermer le modal
            closeAnnotationModal();
            
            // Recharger la page pour voir les changements
            // Ou mettre à jour l'affichage dynamiquement
            window.location.reload();
            
        } else {
            console.error('[Annotation] Erreur:', data.message);
            alert('Erreur: ' + data.message);
        }
    })
    .catch(error => {
        console.error('[Annotation] Erreur réseau:', error);
        alert('Erreur de connexion lors de la sauvegarde');
    })
    .finally(() => {
        // Réactiver le bouton
        saveBtn.disabled = false;
        saveBtn.textContent = originalText;
    });
}

function getCsrfToken() {
    // Récupérer le token CSRF depuis les cookies ou un meta tag
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        const [name, value] = cookie.trim().split('=');
        if (name === 'csrftoken') {
            return value;
        }
    }
    
    // Fallback: chercher dans un meta tag
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    if (metaTag) {
        return metaTag.getAttribute('content');
    }
    
    console.warn('[Annotation] Token CSRF non trouvé');
    return '';
}

// Fermer le modal en cliquant à l'extérieur
document.addEventListener('click', function(event) {
    const modal = document.getElementById('annotationModal');
    if (event.target === modal) {
        closeAnnotationModal();
    }
});

// Fermer le modal avec la touche Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modal = document.getElementById('annotationModal');
        if (modal && modal.style.display === 'flex') {
            closeAnnotationModal();
        }
    }
});

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    console.log('[Annotation] Gestionnaire d\'annotations initialisé');
    
    // Ajouter les event listeners pour les formulaires
    const form = document.getElementById('annotationForm');
    if (form) {
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            saveAnnotation();
        });
    }
});