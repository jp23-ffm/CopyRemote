# views.py
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from collections import defaultdict
from .models import Server, ServerGroupSummary, ServerAnnotation
import time
import json

def server_list(request):
    start_time = time.time()
    print(f"[TIMING] Début de la vue: {time.time():.3f}")
    
    # Récupérer les paramètres de filtre
    hostname_filter = request.GET.get('hostname', '').strip()
    os_filter = request.GET.get('os', '').strip()
    datacenter_filter = request.GET.get('datacenter', '').strip()  # Changé de location à datacenter
    owner_filter = request.GET.get('owner', '').strip()
    application_filter = request.GET.get('application', '').strip()
    
    # Paramètres pour le mode d'affichage
    flat_view = request.GET.get('view', '') == 'flat'
    edit_mode = request.GET.get('edit', '') == 'true'
    
    print(f"[TIMING] Paramètres récupérés: {time.time() - start_time:.3f}s")
    filter_start = time.time()
    
    # Récupérer les serveurs filtrés (QuerySet, pas encore évalué)
    filtered_servers = Server.objects.all()
    
    # Appliquer les filtres
    if hostname_filter:
        filtered_servers = filtered_servers.filter(hostname__icontains=hostname_filter)
    if os_filter:
        filtered_servers = filtered_servers.filter(os__icontains=os_filter)
    if datacenter_filter:
        filtered_servers = filtered_servers.filter(datacenter__icontains=datacenter_filter)
    if owner_filter:
        filtered_servers = filtered_servers.filter(owner__icontains=owner_filter)
    if application_filter:
        filtered_servers = filtered_servers.filter(application__icontains=application_filter)
    
    # Ordonner les résultats filtrés
    filtered_servers = filtered_servers.order_by('hostname', 'application')
    
    print(f"[TIMING] Filtres appliqués: {time.time() - filter_start:.3f}s")
    
    fields_start = time.time()
    
    # Récupérer les champs du modèle (exclure les champs techniques)
    model_fields = []
    excluded_fields = ['id', 'created_at', 'updated_at']
    
    for field in Server._meta.fields:
        if field.name not in excluded_fields:
            model_fields.append({
                'name': field.name,
                'verbose_name': field.verbose_name or field.name.replace('_', ' ').title(),
                'is_hostname': field.name == 'hostname'
            })
    
    # Toujours ajouter la colonne annotations
    model_fields.append({
        'name': 'annotations',
        'verbose_name': 'Annotations',
        'is_hostname': False
    })
    
    print(f"[TIMING] Champs du modèle: {time.time() - fields_start:.3f}s")
    
    # Traitement selon le mode d'affichage
    display_servers = []
    
    if flat_view:
        print(f"[TIMING] Mode plat sélectionné")
        processing_start = time.time()
        
        # PAGINATION PRÉCOCE - Paginer le QuerySet directement
        pagination_start = time.time()
        
        # Utiliser des pages plus petites pour 300k entrées
        paginator = Paginator(filtered_servers, 50)  # Réduit de 50 à 25
        page_obj_raw = paginator.get_page(request.GET.get('page'))
        
        print(f"[TIMING] Pagination QuerySet créée: {time.time() - pagination_start:.3f}s")
        
        # Maintenant convertir seulement la page courante en liste (25 éléments max)
        conversion_start = time.time()
        current_page_servers = list(page_obj_raw)
        print(f"[TIMING] Conversion page courante ({len(current_page_servers)} éléments): {time.time() - conversion_start:.3f}s")
        
        # Récupérer les annotations seulement pour la page courante
        annotations_start = time.time()
        annotations_dict = {}
        hostnames_in_page = [server.hostname for server in current_page_servers]
        if hostnames_in_page:
            annotations = ServerAnnotation.objects.filter(hostname__in=hostnames_in_page)
            annotations_dict = {ann.hostname: ann for ann in annotations}
        print(f"[TIMING] Annotations pour page courante ({len(annotations_dict)} annotations): {time.time() - annotations_start:.3f}s")
        
        # Traitement des serveurs de la page courante
        transform_start = time.time()
        for server in current_page_servers:
            display_servers.append({
                'hostname': server.hostname,
                'count': 1,
                'total_count': 1,
                'hidden_count': 0,
                'has_hidden': False,
                'constant_fields': {},
                'variable_fields': {},
                'all_instances': [server],
                'primary_server': server,
                'is_flat_mode': True,
                'annotation': annotations_dict.get(server.hostname)
            })
        print(f"[TIMING] Transformation des données mode plat: {time.time() - transform_start:.3f}s")
        
        # Créer un objet de pagination avec les données transformées
        class MockPageObj:
            def __init__(self, object_list, page_info):
                self.object_list = object_list
                self.number = page_info.number
                self.paginator = page_info.paginator
                
            def __iter__(self):
                return iter(self.object_list)
                
            def has_previous(self):
                return self.number > 1
                
            def has_next(self):
                return self.number < self.paginator.num_pages
                
            def previous_page_number(self):
                return self.number - 1 if self.has_previous() else None
                
            def next_page_number(self):
                return self.number + 1 if self.has_next() else None
                
            def has_other_pages(self):
                return self.paginator.num_pages > 1
        
        page_obj = MockPageObj(display_servers, page_obj_raw)
        
        print(f"[TIMING] Mode plat traité: {time.time() - processing_start:.3f}s")
        
        # Statistiques pour le mode plat - utiliser count() qui est optimisé
        stats_start = time.time()
        total_servers_stat = paginator.count  # Plus rapide que de recalculer
        total_instances_stat = total_servers_stat
        print(f"[TIMING] Statistiques mode plat: {time.time() - stats_start:.3f}s")
        
    else:
        # MODE GROUPÉ - Optimisation différente
        print(f"[TIMING] Mode groupé sélectionné")
        processing_start = time.time()
        
        # En mode groupé, on a besoin de grouper AVANT de paginer
        # Stratégie: paginer les hostnames directement si pas de filtres
        
        grouping_start = time.time()
        
        # Si aucun filtre, on peut paginer les hostnames directement
        has_filters = any([hostname_filter, os_filter, datacenter_filter, owner_filter, application_filter])
        
        if not has_filters:
            # Sans filtres, paginer les hostnames directement pour éviter de tout charger
            print("[OPTIMIZATION] Pas de filtres - pagination des hostnames")
            
            page_number = int(request.GET.get('page', 1))
            hostnames_per_page = 50  # 25 hostnames par page
            start_hostname = (page_number - 1) * hostnames_per_page
            end_hostname = start_hostname + hostnames_per_page
            
            # Récupérer seulement les hostnames de la page courante
            unique_hostnames = list(
                Server.objects.values_list('hostname', flat=True)
                .distinct()
                .order_by('hostname')[start_hostname:end_hostname]
            )
            
            print(f"[OPTIMIZATION] Page {page_number}: hostnames {start_hostname} à {end_hostname-1} ({len(unique_hostnames)} hostnames)")
            
            # Filtrer pour ne garder que ces hostnames
            filtered_servers = filtered_servers.filter(hostname__in=unique_hostnames)
            
            # Pour la pagination finale, on aura besoin du nombre total d'hostnames
            total_hostnames_count = Server.objects.values('hostname').distinct().count()
            print(f"[OPTIMIZATION] Total hostnames uniques dans la DB: {total_hostnames_count}")
        
        # Maintenant convertir en liste (dataset réduit)
        filtered_servers_list = list(filtered_servers)
        print(f"[TIMING] Conversion en liste pour groupement ({len(filtered_servers_list)} entrées): {time.time() - grouping_start:.3f}s")
        
        # Grouper les serveurs filtrés par hostname
        grouping_step_start = time.time()
        filtered_server_groups = defaultdict(list)
        for server in filtered_servers_list:
            filtered_server_groups[server.hostname].append(server)
        
        print(f"[TIMING] Groupement par hostname ({len(filtered_server_groups)} groupes): {time.time() - grouping_step_start:.3f}s")
        
        # Récupérer les hostnames concernés
        hostnames_list = list(filtered_server_groups.keys())
        
        # Récupérer les résumés pré-calculés
        summaries_start = time.time()
        if hostnames_list:
            summaries_queryset = ServerGroupSummary.objects.filter(hostname__in=hostnames_list)
            summaries_dict = {summary.hostname: summary for summary in summaries_queryset}
            print(f"[TIMING] Résumés récupérés ({len(summaries_dict)} résumés): {time.time() - summaries_start:.3f}s")
        else:
            summaries_dict = {}
            print(f"[TIMING] Aucun résumé à récupérer: {time.time() - summaries_start:.3f}s")
        
        # Créer les objets d'affichage pour groupement
        analysis_start = time.time()
        fallback_count = 0
        grouped_servers = []
        
        for hostname, server_list in filtered_server_groups.items():
            if not server_list:
                continue
            
            # Récupérer le résumé pré-calculé
            summary = summaries_dict.get(hostname)
            
            if summary:
                # Utiliser les données pré-calculées
                visible_count = len(server_list)
                total_count = summary.total_instances
                hidden_count = max(0, total_count - visible_count)
                
                grouped_servers.append({
                    'hostname': hostname,
                    'count': visible_count,
                    'total_count': total_count,
                    'hidden_count': hidden_count,
                    'has_hidden': hidden_count > 0,
                    'constant_fields': summary.constant_fields,
                    'variable_fields': summary.variable_fields,
                    'all_instances': server_list,
                    'primary_server': server_list[0],
                    'is_flat_mode': False,
                })
            else:
                # Fallback : recalculer à la volée si pas de résumé
                fallback_count += 1
                field_analysis = analyze_server_fields(server_list)
                
                grouped_servers.append({
                    'hostname': hostname,
                    'count': len(server_list),
                    'total_count': len(server_list),
                    'hidden_count': 0,
                    'has_hidden': False,
                    'constant_fields': field_analysis['constant'],
                    'variable_fields': field_analysis['variable'],
                    'all_instances': server_list,
                    'primary_server': server_list[0],
                    'is_flat_mode': False,
                })
        
        print(f"[TIMING] Analyse des groupes (fallback: {fallback_count}): {time.time() - analysis_start:.3f}s")
        
        # PAGINATION des groupes
        pagination_start = time.time()
        
        if not has_filters:
            # Pagination spéciale pour le mode sans filtres
            # On a déjà paginé les hostnames, donc pas besoin de repaginer
            
            # Créer un objet paginator factice avec le bon nombre total
            hostnames_per_page = 25
            total_pages = (total_hostnames_count + hostnames_per_page - 1) // hostnames_per_page
            current_page = int(request.GET.get('page', 1))
            
            class CustomPaginator:
                def __init__(self, count, per_page):
                    self.count = count
                    self.per_page = per_page
                    self.num_pages = (count + per_page - 1) // per_page
            
            class CustomPageObj:
                def __init__(self, object_list, page_number, paginator_obj):
                    self.object_list = object_list
                    self.number = page_number
                    self.paginator = paginator_obj
                    
                def __iter__(self):
                    return iter(self.object_list)
                    
                def has_previous(self):
                    return self.number > 1
                    
                def has_next(self):
                    return self.number < self.paginator.num_pages
                    
                def previous_page_number(self):
                    return self.number - 1 if self.has_previous() else None
                    
                def next_page_number(self):
                    return self.number + 1 if self.has_next() else None
                    
                def has_other_pages(self):
                    return self.paginator.num_pages > 1
            
            custom_paginator = CustomPaginator(total_hostnames_count, hostnames_per_page)
            page_obj_raw = CustomPageObj(grouped_servers, current_page, custom_paginator)
            
            print(f"[TIMING] Pagination personnalisée: page {current_page}/{custom_paginator.num_pages}")
            
        else:
            # Pagination normale pour le mode avec filtres
            paginator = Paginator(grouped_servers, 50)
            page_obj_raw = paginator.get_page(request.GET.get('page'))
            print(f"[TIMING] Pagination normale: {len(grouped_servers)} groupes")
        
        
        # Récupérer les annotations seulement pour les groupes de la page courante
        annotations_start = time.time()
        hostnames_in_page = [group['hostname'] for group in page_obj_raw]
        annotations_dict = {}
        if hostnames_in_page:
            annotations = ServerAnnotation.objects.filter(hostname__in=hostnames_in_page)
            annotations_dict = {ann.hostname: ann for ann in annotations}
        print(f"[TIMING] Annotations pour page courante ({len(annotations_dict)} annotations): {time.time() - annotations_start:.3f}s")
        
        # Ajouter les annotations aux groupes de la page
        for group in page_obj_raw:
            group['annotation'] = annotations_dict.get(group['hostname'])
            display_servers.append(group)
        
        page_obj = page_obj_raw
        
        print(f"[TIMING] Pagination et annotations mode groupé: {time.time() - pagination_start:.3f}s")
        print(f"[TIMING] Mode groupé total: {time.time() - processing_start:.3f}s")
        
        # Statistiques pour le mode groupé
        total_servers_stat = len(grouped_servers)
        total_instances_stat = sum(group['count'] for group in grouped_servers)
    
    # Statistiques pour les filtres (valeurs distinctes pour les select)
    stats_start = time.time()
    filter_stats = {
        'os_choices': Server.objects.values_list('os', flat=True).distinct().exclude(os__isnull=True).exclude(os='').order_by('os'),
        'datacenter_choices': Server.objects.values_list('datacenter', flat=True).distinct().exclude(datacenter__isnull=True).exclude(datacenter='').order_by('datacenter'),
        'owner_choices': Server.objects.values_list('owner', flat=True).distinct().exclude(owner__isnull=True).exclude(owner='').order_by('owner'),
    }
    print(f"[TIMING] Statistiques pour filtres: {time.time() - stats_start:.3f}s")
    
    context_start = time.time()
    
    # Vérifier si on a des filtres actifs
    has_filters = any([hostname_filter, os_filter, datacenter_filter, owner_filter, application_filter])
    
    # Contexte avec filtres actuels
    context = {
        'page_obj': page_obj,
        'model_fields': model_fields,
        'total_servers': total_servers_stat,
        'total_instances': total_instances_stat,
        'has_filters': has_filters,
        'flat_view': flat_view,
        'edit_mode': edit_mode,
        'filter_stats': filter_stats,
        'current_filters': {
            'hostname': hostname_filter,
            'os': os_filter,
            'datacenter': datacenter_filter,
            'owner': owner_filter,
            'application': application_filter,
        }
    }
    
    print(f"[TIMING] Contexte préparé: {time.time() - context_start:.3f}s")
    print(f"[TIMING] TOTAL VUE: {time.time() - start_time:.3f}s")
    
    return render(request, 'claude/server_list.html', context)


@login_required
@require_http_methods(["GET", "POST"])
def edit_annotation(request, hostname):
    """Vue pour éditer les annotations d'un serveur"""
    
    if request.method == 'GET':
        # Récupérer l'annotation existante ou créer une nouvelle
        annotation = ServerAnnotation.objects.filter(hostname=hostname).first()
        
        data = {
            'hostname': hostname,
            'status': annotation.status if annotation else 'production',
            'custom_status': annotation.custom_status if annotation else '',
            'notes': annotation.notes if annotation else '',
            'priority': annotation.priority if annotation else 'normal',
        }
        
        return JsonResponse(data)
    
    elif request.method == 'POST':
        # Sauvegarder l'annotation
        try:
            data = json.loads(request.body)
            
            annotation, created = ServerAnnotation.objects.get_or_create(
                hostname=hostname,
                defaults={
                    'created_by': request.user,
                    'updated_by': request.user,
                }
            )
            
            # Mettre à jour les champs
            annotation.status = data.get('status', 'production')
            annotation.custom_status = data.get('custom_status', '')
            annotation.notes = data.get('notes', '')
            annotation.priority = data.get('priority', 'normal')
            annotation.updated_by = request.user
            annotation.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Annotation sauvegardée avec succès',
                'annotation': {
                    'status': annotation.get_display_status(),
                    'priority': annotation.priority,
                    'notes': annotation.notes,
                    'updated_by': annotation.updated_by.username,
                    'updated_at': annotation.updated_at.strftime('%d/%m/%Y %H:%M')
                }
            })
            
        except Exception as e:
            return JsonResponse({
                'success': False,
                'message': f'Erreur lors de la sauvegarde: {str(e)}'
            }, status=400)


def analyze_server_fields(server_list):
    """
    Analyse les champs d'un groupe de serveurs pour identifier
    ceux qui sont constants vs ceux qui varient
    """
    if len(server_list) == 1:
        # Un seul serveur, tous les champs sont "constants"
        server = server_list[0]
        constant_fields = {}
        for field in server._meta.fields:
            if field.name not in ['id', 'created_at', 'updated_at']:
                value = getattr(server, field.name)
                if value:  # Ignorer les valeurs nulles/vides
                    constant_fields[field.name] = str(value)
        return {
            'constant': constant_fields,
            'variable': {}
        }
    
    # Plusieurs serveurs, analyser les différences
    field_values = defaultdict(set)
    
    # Collecter toutes les valeurs pour chaque champ
    for server in server_list:
        for field in server._meta.fields:
            if field.name not in ['id', 'created_at', 'updated_at']:
                value = getattr(server, field.name)
                if value:  # Ignorer les valeurs nulles/vides
                    field_values[field.name].add(str(value))
    
    # Séparer les champs constants des variables
    constant_fields = {}
    variable_fields = {}
    
    for field_name, values in field_values.items():
        if len(values) == 1:
            # Champ constant
            constant_fields[field_name] = list(values)[0]
        else:
            # Champ variable
            variable_fields[field_name] = {
                'count': len(values),
                'preview': f">{len(values)}" if len(values) > 3 else " | ".join(list(values)[:3])
            }
    
    return {
        'constant': constant_fields,
        'variable': variable_fields
    }