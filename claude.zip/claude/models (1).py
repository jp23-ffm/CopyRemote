# models.py
from django.db import models
from django.contrib.auth.models import User
import json

class Server(models.Model):
    # === IDENTITÉ ET RÉSEAU ===
    hostname = models.CharField(max_length=255, db_index=True, verbose_name="Nom d'hôte")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="Adresse IP")
    dns_primary = models.GenericIPAddressField(null=True, blank=True, verbose_name="DNS Primaire")
    dns_secondary = models.GenericIPAddressField(null=True, blank=True, verbose_name="DNS Secondaire")
    gateway = models.GenericIPAddressField(null=True, blank=True, verbose_name="Passerelle")
    subnet_mask = models.CharField(max_length=15, null=True, blank=True, verbose_name="Masque de sous-réseau")
    
    # === SYSTÈME ===
    os = models.CharField(max_length=100, null=True, blank=True, db_index=True, verbose_name="Système d'exploitation")
    os_version = models.CharField(max_length=50, null=True, blank=True, verbose_name="Version OS")
    
    # === MATÉRIEL ===
    ram = models.CharField(max_length=50, null=True, blank=True, verbose_name="RAM")
    cpu = models.CharField(max_length=100, null=True, blank=True, verbose_name="Processeur")
    cpu_cores = models.CharField(max_length=10, null=True, blank=True, verbose_name="Nombre de cœurs")
    storage_type = models.CharField(max_length=50, null=True, blank=True, verbose_name="Type de stockage")
    storage_size = models.CharField(max_length=50, null=True, blank=True, verbose_name="Taille du stockage")
    
    # === INFRASTRUCTURE ===
    datacenter = models.CharField(max_length=100, null=True, blank=True, db_index=True, verbose_name="Centre de données")
    rack = models.CharField(max_length=20, null=True, blank=True, verbose_name="Rack")
    availability_zone = models.CharField(max_length=50, null=True, blank=True, verbose_name="Zone de disponibilité")
    network_vlan = models.CharField(max_length=50, null=True, blank=True, verbose_name="VLAN")
    network_speed = models.CharField(max_length=50, null=True, blank=True, verbose_name="Vitesse réseau")
    
    # === APPLICATIONS ET SERVICES ===
    application = models.CharField(max_length=255, null=True, blank=True, db_index=True, verbose_name="Application")
    service_level = models.CharField(max_length=50, null=True, blank=True, verbose_name="Niveau de service")
    db_instance = models.CharField(max_length=255, null=True, blank=True, verbose_name="Instance de base de données")
    
    # === MANAGEMENT ET PROPRIÉTÉ ===
    owner = models.CharField(max_length=100, null=True, blank=True, db_index=True, verbose_name="Propriétaire")
    business_unit = models.CharField(max_length=100, null=True, blank=True, verbose_name="Unité métier")
    cost_center = models.CharField(max_length=50, null=True, blank=True, verbose_name="Centre de coût")
    project_code = models.CharField(max_length=50, null=True, blank=True, verbose_name="Code projet")
    support_email = models.EmailField(null=True, blank=True, verbose_name="Email de support")
    
    # === VIRTUALISATION ===
    virtualization = models.CharField(max_length=50, null=True, blank=True, verbose_name="Technologie de virtualisation")
    
    # === DATES IMPORTANTES ===
    install_date = models.DateField(null=True, blank=True, verbose_name="Date d'installation")
    last_boot_time = models.DateTimeField(null=True, blank=True, verbose_name="Dernier démarrage")
    warranty_expiry = models.DateField(null=True, blank=True, verbose_name="Fin de garantie")
    purchase_date = models.DateField(null=True, blank=True, verbose_name="Date d'achat")
    
    # === SÉCURITÉ ET COMPLIANCE ===
    security_zone = models.CharField(max_length=50, null=True, blank=True, verbose_name="Zone de sécurité")
    compliance_level = models.CharField(max_length=50, null=True, blank=True, verbose_name="Niveau de conformité")
    antivirus = models.CharField(max_length=100, null=True, blank=True, verbose_name="Antivirus")
    patch_group = models.CharField(max_length=50, null=True, blank=True, verbose_name="Groupe de correctifs")
    
    # === MONITORING ET MAINTENANCE ===
    monitoring_tool = models.CharField(max_length=100, null=True, blank=True, verbose_name="Outil de monitoring")
    backup_policy = models.CharField(max_length=50, null=True, blank=True, verbose_name="Politique de sauvegarde")
    maintenance_window = models.CharField(max_length=100, null=True, blank=True, verbose_name="Fenêtre de maintenance")
    
    # === ÉTATS ACTUELS ===
    power_state = models.CharField(max_length=50, null=True, blank=True, verbose_name="État d'alimentation")
    health_status = models.CharField(max_length=50, null=True, blank=True, verbose_name="État de santé")
    deployment_status = models.CharField(max_length=50, null=True, blank=True, verbose_name="État de déploiement")
    
    # === MÉTRIQUES DE PERFORMANCE ===
    cpu_utilization = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, verbose_name="Utilisation CPU (%)")
    memory_utilization = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, verbose_name="Utilisation mémoire (%)")
    disk_utilization = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, verbose_name="Utilisation disque (%)")
    network_in_mbps = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Réseau entrant (Mbps)")
    network_out_mbps = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Réseau sortant (Mbps)")
    
    # === IDENTIFICATION MATÉRIELLE ===
    serial_number = models.CharField(max_length=50, null=True, blank=True, verbose_name="Numéro de série")
    asset_tag = models.CharField(max_length=50, null=True, blank=True, verbose_name="Tag d'inventaire")
    
    # === NOTES ET COMMENTAIRES ===
    notes = models.TextField(null=True, blank=True, verbose_name="Notes générales")
    configuration_notes = models.TextField(null=True, blank=True, verbose_name="Notes de configuration")
    tags = models.CharField(max_length=500, null=True, blank=True, verbose_name="Tags/Labels")
    
    # === CHAMPS TECHNIQUES (ne pas modifier) ===
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.hostname} - {self.application or 'No App'}"
    
    class Meta:
        ordering = ['hostname']
        indexes = [
            models.Index(fields=['hostname']),
            models.Index(fields=['os']),
            models.Index(fields=['datacenter']),
            models.Index(fields=['owner']),
            models.Index(fields=['application']),
        ]


class ServerGroupSummary(models.Model):
    """
    Table pré-calculée pour optimiser l'affichage groupé.
    Recalculée à chaque import des données.
    """
    hostname = models.CharField(max_length=255, unique=True, db_index=True)
    total_instances = models.PositiveIntegerField()
    
    # Champs constants (JSON) : {field_name: value}
    constant_fields = models.JSONField(default=dict)
    
    # Champs variables (JSON) : {field_name: {"count": 3, "preview": "val1 | val2 | val3"}}
    variable_fields = models.JSONField(default=dict)
    
    # Instance de référence (pour les champs constants)
    primary_server = models.ForeignKey(Server, on_delete=models.CASCADE, related_name='as_primary')
    
    # Métadonnées
    last_updated = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.hostname} ({self.total_instances} instances)"
    
    class Meta:
        ordering = ['hostname']


class ServerAnnotation(models.Model):
    """
    Annotations manuelles persistantes sur les serveurs.
    Survit aux imports de données.
    """
    PRIORITY_CHOICES = [
        ('low', 'Basse'),
        ('normal', 'Normale'),
        ('high', 'Haute'),
        ('critical', 'Critique'),
    ]
    
    STATUS_CHOICES = [
        ('production', 'En production'),
        ('maintenance', 'En maintenance'),
        ('upgrade_needed', 'À upgrader'),
        ('decommission', 'À décommissionner'),
        ('monitoring', 'Sous surveillance'),
        ('custom', 'Personnalisé'),
    ]
    
    hostname = models.CharField(max_length=255, unique=True, db_index=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES, default='production')
    custom_status = models.CharField(max_length=200, blank=True, help_text="Statut personnalisé si 'custom' sélectionné")
    notes = models.TextField(blank=True, help_text="Notes et commentaires détaillés")
    priority = models.CharField(max_length=20, choices=PRIORITY_CHOICES, default='normal')
    
    # Métadonnées d'audit
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='annotations_created')
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='annotations_updated')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def get_display_status(self):
        """Retourne le statut à afficher (custom_status si status='custom', sinon le label du choice)"""
        if self.status == 'custom' and self.custom_status:
            return self.custom_status
        return dict(self.STATUS_CHOICES).get(self.status, self.status)
    
    def get_priority_badge_class(self):
        """Retourne la classe CSS pour le badge de priorité"""
        priority_classes = {
            'low': 'badge-priority-low',
            'normal': 'badge-priority-normal', 
            'high': 'badge-priority-high',
            'critical': 'badge-priority-critical',
        }
        return priority_classes.get(self.priority, 'badge-priority-normal')
    
    def __str__(self):
        return f"{self.hostname} - {self.get_display_status()}"
    
    class Meta:
        ordering = ['hostname']
        verbose_name = "Annotation de serveur"
        verbose_name_plural = "Annotations de serveurs"