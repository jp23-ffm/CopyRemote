from django.urls import path
from . import views

app_name = 'discrepancies'

urlpatterns = [
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('api/trend/', views.trend_api_view, name='trend_api'),
]
