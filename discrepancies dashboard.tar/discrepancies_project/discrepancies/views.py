import json
import os
from django.shortcuts import render
from django.http import JsonResponse
from django.conf import settings
from .models import AnalysisSnapshot
from .utils import get_trend_data


def dashboard_view(request):
    """
    Main dashboard view displaying data quality metrics.
    Renders gauges for overall quality and per-field issues.
    """
    
    # Load dashboard configuration from JSON
    config_path = os.path.join(settings.BASE_DIR, 'config', 'discrepancies_dashboard.json')
    with open(config_path, 'r') as f:
        config = json.load(f)
    
    # Get the latest analysis snapshot
    try:
        latest_snapshot = AnalysisSnapshot.objects.latest('analysis_date')
    except AnalysisSnapshot.DoesNotExist:
        # No analysis has been run yet
        context = {
            'no_data': True,
            'message': 'No analysis has been run yet. Please run the discrepancy analysis first.'
        }
        return render(request, 'discrepancies/dashboard.html', context)
    
    # Prepare widget data
    widgets_data = []
    
    for widget in config['dashboard']['widgets']:
        widget_data = {
            'id': widget['id'],
            'type': widget['type'],
            'size': widget.get('size', 'small'),
            'title': widget['title'],
            'icon': widget.get('icon', ''),
            'link': widget.get('link', '#'),
        }
        
        # Retrieve metric value from snapshot
        metric_name = widget['metric']
        metric_value = getattr(latest_snapshot, metric_name, 0)
        
        if widget['type'] == 'gauge':
            if widget['size'] == 'large':
                # Large gauge: displays percentage directly
                widget_data['value'] = metric_value
                widget_data['display_value'] = f"{metric_value}%"
            else:
                # Small gauge: calculate percentage of servers OK for this field
                # metric_value = number of servers with issues in this field
                total = latest_snapshot.total_servers_analyzed
                servers_ok = total - metric_value
                percentage_ok = round((servers_ok / total) * 100, 1) if total > 0 else 100
                
                widget_data['value'] = percentage_ok
                widget_data['count'] = metric_value
                widget_data['display_value'] = f"{percentage_ok}%"
                widget_data['detail'] = f"{metric_value} issues"
            
            # Thresholds and colors for gauge coloring
            widget_data['thresholds'] = widget.get('thresholds', {
                'critical': 80,
                'warning': 95,
                'good': 100
            })
            widget_data['colors'] = widget.get('colors', {
                'critical': '#dc3545',
                'warning': '#ffc107',
                'good': '#28a744'
            })
        
        widgets_data.append(widget_data)
    
    # Prepare historical trend data (default metric)
    historic_config = config['dashboard'].get('historic_section', {})
    
    if historic_config.get('enabled', False):
        default_metric = historic_config.get('default_metric', 'servers_with_issues')
        days = historic_config.get('days', 30)
        trend_data = get_trend_data(default_metric, days)
    else:
        historic_config = None
        trend_data = None
    
    context = {
        'title': config['dashboard']['title'],
        'widgets': widgets_data,
        'snapshot': latest_snapshot,
        'no_data': False,
        'historic_config': historic_config,
        'trend_data': trend_data,
    }
    
    return render(request, 'discrepancies/dashboard.html', context)


def trend_api_view(request):
    """
    API endpoint for retrieving trend data for a specific metric.
    Called via AJAX when user changes the metric selector.
    
    Query params:
        - metric: Field name from AnalysisSnapshot
        - days: Number of days to look back (default: 30)
    
    Returns:
        JSON with dates (labels) and values
    """
    
    metric = request.GET.get('metric', 'servers_with_issues')
    days = int(request.GET.get('days', 30))
    
    data = get_trend_data(metric, days)
    
    return JsonResponse({
        'labels': data['dates'],
        'values': data['values'],
        'metric': metric
    })
