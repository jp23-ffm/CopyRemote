# Discrepancies Dashboard - Installation Guide

This package provides a complete Django app for displaying data quality dashboards with interactive gauges and trend charts.

## Project Structure

```
discrepancies_project/
├── common/                          # Shared components across apps
│   ├── static/common/
│   │   ├── css/
│   │   │   └── dashboard.css       # Dashboard styling with light/dark mode
│   │   └── js/
│   │       └── gauges.js           # Gauge chart creation utilities
│   └── templates/common/
│       └── dashboard_base.html     # Base template for dashboards
│
├── discrepancies/                   # Main discrepancies app
│   ├── management/commands/
│   │   └── analyze_discrepancies.py  # Management command (placeholder)
│   ├── static/discrepancies/js/
│   │   └── trend.js                # Trend chart with AJAX updates
│   ├── templates/discrepancies/
│   │   └── dashboard.html          # Discrepancies dashboard template
│   ├── __init__.py
│   ├── admin.py                    # Django admin configuration
│   ├── models.py                   # ServerDiscrepancy & AnalysisSnapshot models
│   ├── urls.py                     # URL routing
│   ├── utils.py                    # Helper functions
│   └── views.py                    # Dashboard and API views
│
└── config/
    └── discrepancies_dashboard.json  # Dashboard configuration
```

## Installation Steps

### 1. Copy Files to Your Django Project

Copy the following directories to your Django project root:
- `common/`
- `discrepancies/`
- `config/`

### 2. Update Django Settings

Add the new apps to your `INSTALLED_APPS` in `settings.py`:

```python
INSTALLED_APPS = [
    # ... your existing apps
    'common',
    'discrepancies',
]
```

### 3. Update Main URLs

In your project's main `urls.py`, add:

```python
from django.urls import path, include

urlpatterns = [
    # ... your existing URLs
    path('discrepancies/', include('discrepancies.urls')),
]
```

### 4. Run Migrations

```bash
python manage.py makemigrations discrepancies
python manage.py migrate
```

### 5. Create Sample Data (Optional)

For testing, you can create a sample AnalysisSnapshot:

```python
from discrepancies.models import AnalysisSnapshot
from django.utils import timezone

AnalysisSnapshot.objects.create(
    analysis_date=timezone.now(),
    total_servers_analyzed=5000,
    servers_with_issues=189,
    servers_clean=4811,
    missing_datacenter_count=145,
    missing_environment_count=89,
    missing_live_status_count=67,
    missing_machine_type_count=43,
    missing_region_count=32,
    missing_osfamily_count=28,
    duration_seconds=15.5
)
```

### 6. Access the Dashboard

Visit: `http://localhost:8000/discrepancies/dashboard/`

## Configuration

### Dashboard Configuration

Edit `config/discrepancies_dashboard.json` to:
- Add/remove gauge widgets
- Change colors and thresholds
- Configure trend chart metrics
- Modify links to filtered views

### Dark Mode

To enable dark mode, add `data-theme="dark"` to the `<body>` tag in your base template:

```html
<body data-theme="dark">
```

You can toggle this dynamically with JavaScript based on user preference.

## Integration with Existing Analysis

Replace the placeholder in `discrepancies/management/commands/analyze_discrepancies.py` with your existing analysis logic:

1. Query your Server model
2. Check for invalid/missing fields
3. Create `ServerDiscrepancy` records with `_ok` boolean fields
4. Create `AnalysisSnapshot` with summary statistics

## Features

✅ **Responsive Gauges**: Semi-circular gauge charts for visual quality metrics
✅ **Trend Charts**: Historical data with AJAX-powered metric switching
✅ **Light/Dark Mode**: CSS variables for easy theme switching
✅ **JSON Configuration**: Add widgets without touching code
✅ **Reusable Components**: Common CSS/JS for use across multiple apps
✅ **Clean Architecture**: Separation of concerns with models, views, utils

## API Endpoints

- `/discrepancies/dashboard/` - Main dashboard view
- `/discrepancies/api/trend/?metric=<metric_name>&days=<days>` - Trend data API

## Troubleshooting

**Issue**: "No analysis has been run yet"
- **Solution**: Create an `AnalysisSnapshot` record or run your analysis command

**Issue**: Dashboard not loading styles
- **Solution**: Run `python manage.py collectstatic` in production

**Issue**: Trend chart not updating
- **Solution**: Check browser console for JavaScript errors and verify API endpoint

## Support

For questions or issues, refer to the inline code comments (in English) throughout the codebase.

## License

This code is provided as-is for your Django project.
