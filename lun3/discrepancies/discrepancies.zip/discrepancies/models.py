from django.db import models
from django.utils import timezone


class ServerDiscrepancy(models.Model):
    """
    Stores servers with data quality issues detected during analysis.
    Each record represents a server that has at least one invalid or missing field.
    Missing/invalid values are stored as 'MISSING' for easy filtering.
    """
    
    SERVER_ID = models.CharField(max_length=100, db_index=True)
    analysis_date = models.DateTimeField()
    
    # Comma-separated list of missing field names
    missing_fields = models.TextField(blank=True)
    
    # Data fields being validated
    # Values are stored as-is if valid, or 'MISSING' if invalid/empty
    LIVE_STATUS = models.CharField(max_length=200, blank=True, null=True)
    OSSHORTNAME = models.CharField(max_length=200, blank=True, null=True)
    OSFAMILY = models.CharField(max_length=200, blank=True, null=True)
    SNOW_SUPPORTGROUP = models.CharField(max_length=200, blank=True, null=True)
    MACHINE_TYPE = models.CharField(max_length=100, blank=True, null=True)
    MANUFACTURER = models.CharField(max_length=200, blank=True, null=True)
    COUNTRY = models.CharField(max_length=100, blank=True, null=True)
    APP_AUID_VALUE = models.CharField(max_length=100, blank=True, null=True)
    APP_NAME_VALUE = models.CharField(max_length=100, blank=True, null=True)
    REGION = models.CharField(max_length=200, blank=True, null=True)
    CITY = models.CharField(max_length=200, blank=True, null=True)
    INFRAVERSION = models.CharField(max_length=50, blank=True, null=True)
    IPADDRESS = models.CharField(max_length=100, blank=True, null=True)
    SNOW_STATUS = models.CharField(max_length=50, blank=True, null=True)
    IDRAC_NAME = models.CharField(max_length=200, blank=True, null=True)
    IDRAC_IP = models.CharField(max_length=100, blank=True, null=True)
    
    # Validation error flags (boolean)
    # These flags indicate logical inconsistencies between fields
    alive_status_inconsistent = models.CharField(max_length=50, blank=True, null=True)
    dead_status_inconsistent = models.CharField(max_length=50, blank=True, null=True)

    
    class Meta:
        db_table = 'discrepancies_serverdiscrepancy'
        indexes = [
            models.Index(fields=['analysis_date']),
            models.Index(fields=['SERVER_ID', 'analysis_date']),
        ]
    
    def __str__(self):
        return f"{self.SERVER_ID} - {self.analysis_date}"


class AnalysisSnapshot(models.Model):
    """
    Summary statistics for each analysis run.
    Stores pre-calculated metrics for fast dashboard rendering.
    """
    
    analysis_date = models.DateTimeField(unique=True, db_index=True)
    
    # Global metrics
    total_servers_analyzed = models.IntegerField()
    total_physical_servers = models.IntegerField()
    servers_with_issues = models.IntegerField()
    servers_clean = models.IntegerField()
    
    # Per-field issue counts
    missing_live_status_count = models.IntegerField(default=0)
    missing_osshortname_count = models.IntegerField(default=0)
    missing_osfamily_count = models.IntegerField(default=0)
    missing_snow_supportgroup_count = models.IntegerField(default=0)
    missing_machine_type_count = models.IntegerField(default=0)
    missing_manufacturer_count = models.IntegerField(default=0)
    missing_country_count = models.IntegerField(default=0)
    missing_app_auid_value_count = models.IntegerField(default=0)
    missing_app_name_value_count = models.IntegerField(default=0)
    missing_region_count = models.IntegerField(default=0)
    missing_city_count = models.IntegerField(default=0)
    missing_infraversion_count = models.IntegerField(default=0)
    missing_ipaddress_count = models.IntegerField(default=0)
    missing_snow_status_count = models.IntegerField(default=0)
    missing_idrac_name_count = models.IntegerField(default=0)
    missing_idrac_ip_count = models.IntegerField(default=0)    
    
    # Validation error counts
    alive_status_inconsistent_count = models.IntegerField(default=0)
    dead_status_inconsistent_count = models.IntegerField(default=0)

    # Diff vs previous run
    new_issues_count      = models.IntegerField(default=0)
    resolved_issues_count = models.IntegerField(default=0)
    changed_issues_count  = models.IntegerField(default=0)
    # {'new': [...], 'resolved': [...], 'changed': {server_id: {'added': [...], 'removed': [...]}}}
    diff_summary = models.JSONField(default=dict)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    duration_seconds = models.FloatField(null=True, blank=True)
    
    class Meta:
        db_table = 'discrepancies_analysissnapshot'
        ordering = ['-analysis_date']
    
    def __str__(self):
        return f"Analysis {self.analysis_date} - {self.servers_with_issues}/{self.total_servers_analyzed} issues"
    
    @property
    def percentage_with_issues(self):
        """Calculate percentage of servers with issues"""
        if self.total_servers_analyzed == 0:
            return 0
        return round((self.servers_with_issues / self.total_servers_analyzed) * 100, 2)
    
    @property
    def percentage_clean(self):
        """Calculate percentage of clean servers"""
        return round(100 - self.percentage_with_issues, 2)
        



class DiscrepancyTracking(models.Model):
    """
    Tracks active discrepancy issues per server.
    One row per server. active_issues stores per-field first_seen timestamps.
    When a field is fixed it is simply removed from active_issues.
    """

    SERVER_ID = models.CharField(max_length=100)

    # {field_name: {"first_seen": "<ISO datetime>"}}
    active_issues = models.JSONField(default=dict)

    # Denormalised: oldest first_seen across active_issues — kept in sync for fast SQL sorting
    oldest_first_seen = models.DateTimeField(null=True, blank=True)

    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'discrepancies_discrepancytracking'
        constraints = [
            models.UniqueConstraint(fields=['SERVER_ID'], name='disctracking_serverid_uniq'),
        ]
        indexes = [
            models.Index(fields=['oldest_first_seen'], name='disctracking_oldest_idx'),
        ]

    def __str__(self):
        return f"{self.SERVER_ID} - {len(self.active_issues)} active issues"

    @property
    def issues_count(self):
        return len(self.active_issues)


class DiscrepancyAnnotation(models.Model):
    SERVER_ID = models.CharField(max_length=255, unique=True, db_index=True)
    comment = models.TextField(blank=True)
    assigned_to = models.CharField(max_length=150, blank=True)
    history = models.JSONField(default=list)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'discrepancies_discrepancyannotation'

    def add_entry(self, comment, assigned_to, user):
        if not self.history:
            self.history = []
        self.history.append({
            'comment': comment,
            'assigned_to': assigned_to,
            'user': user.username if user else 'Unknown',
            'date': timezone.now().isoformat(),
        })
        self.comment = comment
        self.assigned_to = assigned_to
        self.save()

    def get_history_display(self):
        if not self.history:
            return []
        return sorted(self.history, key=lambda x: x['date'], reverse=True)
        

class ExcludedServer(models.Model):
    # Servers manually excluded from discrepancy analysis. Managed via the dashboard UI (add/delete/export).

    server_name = models.CharField(max_length=255)
    reason = models.TextField(blank=True)
    owner = models.CharField(max_length=150, blank=True)
    exclusion_date = models.DateField(null=True, blank=True)
    created_by = models.CharField(max_length=150, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'discrepancies_excludedserver'
        ordering = ['server_name']

    def __str__(self):
        return self.server_name

class ImportStatus(models.Model):
    date_import = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField(default=False)
    message = models.TextField(blank=True, null=True)
    nb_entries_created = models.IntegerField(default=0)

    def __str__(self):
        return f"{'OK' if self.success else 'KO'} {self.date_import.strftime('%d.%m.%Y %H:%M')}"
