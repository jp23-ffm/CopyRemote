# Full inventory seeder for pre-dev environments.
# Replaces ALL field values on every Server row with realistic fake data.
#
# Usage:
#   python manage.py seed_inventory
#   python manage.py seed_inventory --batch 2000   (tune bulk_update chunk size)

import random
import time

from django.core.management.base import BaseCommand

from inventory.models import Server


# ---------------------------------------------------------------------------
# Fake value pools
# ---------------------------------------------------------------------------

LIVE_STATUS_CHOICES = [
    ('ALIVE', 70),   # (value, weight)
    ('DEAD',  30),
]

SNOW_STATUS_CHOICES = [
    ('OPERATIONAL',     60),
    ('NON-OPERATIONAL', 20),
    ('RETIRED',         20),
]

INFRAVERSION_CHOICES = [
    ('IV1',    30),
    ('IV2',    28),
    ('IBM',    17),
    ('IV3',    12),   # fake
    ('LEGACY',  8),   # fake
    ('CLOUD',   5),   # fake
]

MACHINE_TYPE_CHOICES = [
    ('VIRTUAL',  65),
    ('PHYSICAL', 35),
]

OSFAMILY_CHOICES = ['LINUX', 'WINDOWS', 'UNIX']

OSSHORTNAME_BY_FAMILY = {
    'LINUX':   ['RHEL7', 'RHEL8', 'RHEL9', 'UBUNTU20', 'UBUNTU22', 'DEBIAN11', 'SLES15'],
    'WINDOWS': ['WIN2016', 'WIN2019', 'WIN2022', 'WIN2012R2'],
    'UNIX':    ['AIX7', 'SOLARIS11', 'HPUX11'],
}

MANUFACTURER_CHOICES = ['DELL', 'HP', 'IBM', 'LENOVO', 'CISCO', 'FUJITSU', 'SUPERMICRO']

COUNTRY_CHOICES = ['FR', 'US', 'DE', 'GB', 'SG', 'IN', 'AU', 'JP', 'NL', 'BE']

REGION_CHOICES = ['EMEA', 'AMER', 'APAC']

CITY_BY_REGION = {
    'EMEA': ['PARIS', 'LONDON', 'FRANKFURT', 'AMSTERDAM', 'BRUSSELS'],
    'AMER': ['NEW YORK', 'DALLAS', 'CHICAGO', 'SAO PAULO', 'TORONTO'],
    'APAC': ['SINGAPORE', 'TOKYO', 'SYDNEY', 'MUMBAI', 'HONG KONG'],
}

SNOW_SUPPORTGROUP_CHOICES = [
    'INFRA-LINUX', 'INFRA-WINDOWS', 'INFRA-STORAGE', 'INFRA-NETWORK',
    'APP-SUPPORT-L1', 'APP-SUPPORT-L2', 'DB-ORACLE', 'DB-MSSQL',
    'MIDDLEWARE-JBOSS', 'MIDDLEWARE-WEBLOGIC', 'CLOUD-OPS', 'SECURITY-OPS',
]

APP_NAME_POOL = [
    'APOLLO', 'HERMES', 'ZEUS', 'ATHENA', 'ARES', 'POSEIDON',
    'ARTEMIS', 'HEPHAESTUS', 'DEMETER', 'DIONYSUS', 'HADES', 'HERA',
    'KRONOS', 'TITAN', 'PROMETHEUS', 'ICARUS', 'ORPHEUS', 'DAEDALUS',
]

ENVIRONMENT_CHOICES = ['PRODUCTION', 'STAGING', 'DEVELOPMENT', 'QA', 'DR']
SHORT_ENV_MAP = {
    'PRODUCTION': 'PROD', 'STAGING': 'STG', 'DEVELOPMENT': 'DEV',
    'QA': 'QA', 'DR': 'DR',
}

SNOW_DATACENTER_CHOICES = [
    'DC-PARIS-1', 'DC-LONDON-1', 'DC-FRANKFURT-1',
    'DC-DALLAS-1', 'DC-SINGAPORE-1', 'DC-SYDNEY-1',
]

TECHFAMILY_CHOICES = ['SERVER', 'VIRTUAL_MACHINE', 'CONTAINER', 'APPLIANCE']


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def weighted_choice(choices):
    values, weights = zip(*choices)
    return random.choices(values, weights=weights, k=1)[0]


def fake_ip():
    return f"10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"


def fake_auid():
    return f"AUID-{random.randint(1000, 9999)}"


def fake_idrac_name(server_id):
    return f"IDRAC-{server_id}"


def fake_idrac_ip():
    return f"192.168.{random.randint(0,255)}.{random.randint(1,254)}"


def fake_model(manufacturer):
    models_by_vendor = {
        'DELL':       ['PowerEdge R740', 'PowerEdge R640', 'PowerEdge R940'],
        'HP':         ['ProLiant DL380', 'ProLiant DL360', 'ProLiant BL460c'],
        'IBM':        ['Power9', 'Power10', 'System x3650'],
        'LENOVO':     ['ThinkSystem SR650', 'ThinkSystem SR630'],
        'CISCO':      ['UCS C240', 'UCS C220', 'UCS B200'],
        'FUJITSU':    ['PRIMERGY RX2540', 'PRIMERGY TX1330'],
        'SUPERMICRO': ['SuperServer 6029P', 'SuperServer 1029P'],
    }
    return random.choice(models_by_vendor.get(manufacturer, ['GENERIC-MODEL']))


def build_server_data(server):
    """Return a dict of all fields to set on a single server."""

    live_status   = weighted_choice(LIVE_STATUS_CHOICES)
    snow_status   = weighted_choice(SNOW_STATUS_CHOICES)
    infraversion  = weighted_choice(INFRAVERSION_CHOICES)
    machine_type  = weighted_choice(MACHINE_TYPE_CHOICES)
    osfamily      = random.choice(OSFAMILY_CHOICES)
    osshortname   = random.choice(OSSHORTNAME_BY_FAMILY[osfamily])
    manufacturer  = random.choice(MANUFACTURER_CHOICES)
    region        = random.choice(REGION_CHOICES)
    city          = random.choice(CITY_BY_REGION[region])
    country       = random.choice(COUNTRY_CHOICES)
    environment   = random.choice(ENVIRONMENT_CHOICES)
    app_name      = random.choice(APP_NAME_POOL)
    snow_dc       = random.choice(SNOW_DATACENTER_CHOICES)
    sg            = random.choice(SNOW_SUPPORTGROUP_CHOICES)

    return dict(
        LIVE_STATUS     = live_status,
        SNOW_STATUS     = snow_status,
        INFRAVERSION    = infraversion,
        MACHINE_TYPE    = machine_type,
        OSFAMILY        = osfamily,
        OSSHORTNAME     = osshortname,
        OSFULLVERSION   = f"{osshortname}-{random.randint(1,5)}.{random.randint(0,9)}",
        OS              = osshortname,
        MANUFACTURER    = manufacturer,
        MODEL           = fake_model(manufacturer),
        REGION          = region,
        CITY            = city,
        COUNTRY         = country,
        ENVIRONMENT     = environment,
        SHORT_ENVIRONMENT = SHORT_ENV_MAP[environment],
        APP_NAME_VALUE  = app_name,
        APP_AUID_VALUE  = fake_auid(),
        SNOW_SUPPORTGROUP = sg,
        SNOW_DATACENTER = snow_dc,
        IPADDRESS       = fake_ip(),
        SERVER_IP       = fake_ip(),
        FQDN            = f"{server.SERVER_ID.lower()}.{city.lower().replace(' ','-')}.corp",
        # IDRAC only for physical
        IDRAC_NAME      = fake_idrac_name(server.SERVER_ID) if machine_type == 'PHYSICAL' else None,
        IDRAC_IP        = fake_idrac_ip()                   if machine_type == 'PHYSICAL' else None,
        # Misc
        TECHFAMILY      = random.choice(TECHFAMILY_CHOICES),
        APP_CRITICALITY = random.choice(['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']),
        SERIAL          = f"SN{random.randint(100000, 999999)}",
        RAM             = str(random.choice([16, 32, 64, 128, 256])),
        CPU             = str(random.choice([4, 8, 16, 32, 64])),
        DISK            = str(random.choice([200, 500, 1000, 2000, 4000])),
        VMTYPE          = 'VM' if machine_type == 'VIRTUAL' else 'PHYSICAL',
        PERIMETER       = random.choice(['INTERNAL', 'DMZ', 'EXTERNAL']),
        SUBPERIMETER    = random.choice(['ZONE-A', 'ZONE-B', 'ZONE-C']),
    )


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------

UPDATABLE_FIELDS = [
    'LIVE_STATUS', 'SNOW_STATUS', 'INFRAVERSION', 'MACHINE_TYPE',
    'OSFAMILY', 'OSSHORTNAME', 'OSFULLVERSION', 'OS',
    'MANUFACTURER', 'MODEL',
    'REGION', 'CITY', 'COUNTRY',
    'ENVIRONMENT', 'SHORT_ENVIRONMENT',
    'APP_NAME_VALUE', 'APP_AUID_VALUE',
    'SNOW_SUPPORTGROUP', 'SNOW_DATACENTER',
    'IPADDRESS', 'SERVER_IP', 'FQDN',
    'IDRAC_NAME', 'IDRAC_IP',
    'TECHFAMILY', 'APP_CRITICALITY',
    'SERIAL', 'RAM', 'CPU', 'DISK', 'VMTYPE',
    'PERIMETER', 'SUBPERIMETER',
]


class Command(BaseCommand):
    help = 'Pre-dev seeder: replace ALL inventory.Server field values with realistic fake data.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--batch',
            type=int,
            default=1000,
            help='bulk_update chunk size (default: 1000)',
        )

    def handle(self, *args, **options):
        batch_size = options['batch']

        from django.db import connection

        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT rowid, SERVER_ID, MACHINE_TYPE FROM inventory_server"
            )
            rows = cursor.fetchall()

        total = len(rows)
        if total == 0:
            self.stderr.write('No servers found in DB.')
            return

        self.stdout.write(f'Seeding {total:,} servers (batch={batch_size})...')
        t0 = time.time()

        # Build the SET clause dynamically from UPDATABLE_FIELDS
        set_clause = ', '.join(f'"{f}"=?' for f in UPDATABLE_FIELDS)
        sql = f'UPDATE inventory_server SET {set_clause} WHERE rowid=?'

        processed = 0
        chunk = []

        for rowid, server_id, machine_type in rows:
            # Build a minimal stub just to pass SERVER_ID/MACHINE_TYPE to build_server_data
            stub = Server(SERVER_ID=server_id, MACHINE_TYPE=machine_type)
            data = build_server_data(stub)

            # Row = ordered values for UPDATABLE_FIELDS + rowid at the end
            row = [data.get(f) for f in UPDATABLE_FIELDS] + [rowid]
            chunk.append(row)

            if len(chunk) >= batch_size:
                with connection.cursor() as cursor:
                    cursor.executemany(sql, chunk)
                processed += len(chunk)
                chunk = []
                elapsed = time.time() - t0
                rate = processed / elapsed
                remaining = (total - processed) / rate if rate else 0
                self.stdout.write(
                    f'  {processed:,}/{total:,}  '
                    f'({processed/total*100:.1f}%)  '
                    f'~{remaining:.0f}s remaining',
                    ending='\r',
                )
                self.stdout.flush()

        if chunk:
            with connection.cursor() as cursor:
                cursor.executemany(sql, chunk)
            processed += len(chunk)

        elapsed = time.time() - t0
        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS(
            f'Done — {processed:,} servers seeded in {elapsed:.1f}s'
        ))
        self.stdout.write('')

        # Quick distribution summary
        from django.db.models import Count
        self.stdout.write('--- Distribution ---')
        for field, label in [
            ('LIVE_STATUS',  'LIVE_STATUS'),
            ('SNOW_STATUS',  'SNOW_STATUS'),
            ('INFRAVERSION', 'INFRAVERSION'),
            ('MACHINE_TYPE', 'MACHINE_TYPE'),
        ]:
            rows = (
                Server.objects.values(field)
                .annotate(n=Count('id'))
                .order_by('-n')
            )
            self.stdout.write(f'{label}:')
            for r in rows:
                self.stdout.write(f"  {r[field]:<20} {r['n']:>7,}")

        # How many will be picked up by analyze_discrepancies
        eligible = Server.objects.filter(
            LIVE_STATUS='ALIVE',
            SNOW_STATUS='OPERATIONAL',
            INFRAVERSION__in=['IV1', 'IV2', 'IBM'],
        ).count()
        self.stdout.write(f'\nEligible for analyze_discrepancies: {eligible:,}')
