# Inject synthetic discrepancies into inventory.Server for testing purposes.
# Uses raw SQL + SQLite rowid to bypass the missing-pk issue.
#
# Usage:
#   python manage.py seed_discrepancies
#   python manage.py seed_discrepancies --count 50
#   python manage.py seed_discrepancies --undo

import json
import random

from django.core.management.base import BaseCommand
from django.db import connection

from inventory.models import Server

FIELDS_TO_CHECK = [
    'LIVE_STATUS', 'OSSHORTNAME', 'OSFAMILY', 'SNOW_SUPPORTGROUP',
    'MACHINE_TYPE', 'MANUFACTURER', 'COUNTRY', 'APP_AUID_VALUE',
    'APP_NAME_VALUE', 'REGION', 'CITY', 'INFRAVERSION', 'IPADDRESS',
    'SNOW_STATUS', 'IDRAC_NAME', 'IDRAC_IP',
]

HARDWARE_ONLY = {'IDRAC_NAME', 'IDRAC_IP'}
PROTECTED     = {'LIVE_STATUS', 'SNOW_STATUS', 'INFRAVERSION'}

EMPTY_VALUE = 'EMPTY'
BACKUP_FILE = 'seed_discrepancies_backup.json'


class Command(BaseCommand):
    help = 'Inject EMPTY values into random servers so analyze_discrepancies has something to find.'

    def add_arguments(self, parser):
        parser.add_argument('--count', type=int, default=None,
                            help='Servers to corrupt (20-100). Random if omitted.')
        parser.add_argument('--undo', action='store_true',
                            help=f'Restore original values from {BACKUP_FILE}')

    def handle(self, *args, **options):
        if options['undo']:
            self._undo()
        else:
            self._seed(options['count'])

    # ------------------------------------------------------------------
    def _seed(self, requested_count):
        count = requested_count or random.randint(20, 100)
        count = max(20, min(100, count))
        self.stdout.write(f'Target: corrupt {count} servers')

        # Step 1 — fetch eligible rows with SQLite rowid
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT rowid, SERVER_ID, MACHINE_TYPE FROM inventory_server"
                " WHERE LIVE_STATUS='ALIVE' AND SNOW_STATUS='OPERATIONAL'"
                " AND INFRAVERSION IN ('IV1','IV2','IBM')"
            )
            all_rows = cursor.fetchall()   # [(rowid, server_id, machine_type), ...]

        total = len(all_rows)
        self.stdout.write(f'Eligible servers: {total}')

        if total < count:
            self.stderr.write(
                f'Not enough eligible servers (need {count}, found {total}). Aborting.'
            )
            return

        chosen = random.sample(all_rows, count)

        # Step 2 — decide which fields to corrupt per row
        plan = {}   # rowid -> {server_id, fields}
        for rowid, server_id, machine_type in chosen:
            candidates = [
                f for f in FIELDS_TO_CHECK
                if f not in PROTECTED
                and not (f in HARDWARE_ONLY and machine_type != 'PHYSICAL')
            ]
            if not candidates:
                continue
            n = random.randint(1, min(3, len(candidates)))
            plan[rowid] = {'server_id': server_id, 'fields': random.sample(candidates, n)}

        if not plan:
            self.stderr.write('No corruptible fields found. Aborting.')
            return

        # Step 3 — fetch original values (for backup / undo)
        all_fields_needed = sorted({f for p in plan.values() for f in p['fields']})
        rowids = list(plan.keys())
        rowids_ph = ','.join(['%s'] * len(rowids))
        fields_sql = ', '.join(f'"{f}"' for f in all_fields_needed)

        with connection.cursor() as cursor:
            cursor.execute(
                f'SELECT rowid, {fields_sql} FROM inventory_server'
                f' WHERE rowid IN ({rowids_ph})',
                rowids
            )
            cols = [d[0] for d in cursor.description]   # cols[0] = 'rowid'
            for row in cursor.fetchall():
                rowid = row[0]
                if rowid in plan:
                    plan[rowid]['original'] = {
                        cols[i]: row[i]
                        for i in range(1, len(cols))
                        if cols[i] in plan[rowid]['fields']
                    }

        # Step 4 — save backup
        backup = [
            {'rowid': rowid, 'SERVER_ID': p['server_id'], 'original': p.get('original', {})}
            for rowid, p in plan.items()
        ]
        with open(BACKUP_FILE, 'w') as fh:
            json.dump(backup, fh, indent=2)
        self.stdout.write(f'Backup saved to {BACKUP_FILE}')

        # Step 5 — apply corruption (group by field for batch UPDATEs)
        field_to_rowids = {}
        field_stats = {}
        for rowid, p in plan.items():
            for field in p['fields']:
                field_to_rowids.setdefault(field, []).append(rowid)
                field_stats[field] = field_stats.get(field, 0) + 1

        with connection.cursor() as cursor:
            for field, rids in field_to_rowids.items():
                ph = ','.join(['%s'] * len(rids))
                cursor.execute(
                    f'UPDATE inventory_server SET "{field}"=%s WHERE rowid IN ({ph})',
                    [EMPTY_VALUE] + rids
                )

        # Report
        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS(f'Done — {len(plan)} servers corrupted'))
        self.stdout.write('Fields set to EMPTY:')
        for field, cnt in sorted(field_stats.items(), key=lambda x: -x[1]):
            self.stdout.write(f'  {field}: {cnt}')
        self.stdout.write('')
        self.stdout.write('Run analyze_discrepancies to see results.')
        self.stdout.write(f'Run with --undo to restore original values.')

    # ------------------------------------------------------------------
    def _undo(self):
        try:
            with open(BACKUP_FILE) as fh:
                backup = json.load(fh)
        except FileNotFoundError:
            self.stderr.write(f'{BACKUP_FILE} not found. Nothing to restore.')
            return

        updated = 0
        with connection.cursor() as cursor:
            for entry in backup:
                rowid = entry['rowid']
                original = entry.get('original', {})
                for field, value in original.items():
                    cursor.execute(
                        f'UPDATE inventory_server SET "{field}"=%s WHERE rowid=%s',
                        [value, rowid]
                    )
                if original:
                    updated += 1

        self.stdout.write(self.style.SUCCESS(f'Restored {updated} servers from backup.'))
